package br.com.digicon.remessaBoleto.exception;

/**
 * Exception ocasionada por erros no processo de criptografia
 *
 * @author Eduardo
 *
 */
public class DigiconEncryptorException extends DigiconException {

	private static final long serialVersionUID = -3547066946196628562L;

	public DigiconEncryptorException( String mensagem ){
		super( mensagem );
	}

	public DigiconEncryptorException( String mensagem, Throwable causa ){
		super( mensagem, causa );
	}

	public DigiconEncryptorException( Throwable causa ){
		super( causa );
	}
}
