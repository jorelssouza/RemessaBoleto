/**
 *
 */
package br.com.digicon.remessaBoleto.exception;

/**
 * Classe macro para exce��es geradas pela aplica��o. Deve ser sempre lan�ada
 * como a �ltima camada no tratamento de exce��es.
 *
 * @author Daniel
 *
 */
public class DigiconException extends Exception {

	private static final long serialVersionUID = -1832660440317708726L;

	public DigiconException( String mensagem ){
		super( mensagem );
	}

	public DigiconException( String mensagem, Throwable causa ){
		super( mensagem, causa );
	}

	public DigiconException( Throwable causa ){
		super( causa );
	}
}
