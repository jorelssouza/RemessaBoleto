package br.com.digicon.remessaBoleto.exception;

/**
 *
 * @author renato
 * @author $Author: renato $
 * @version $Rev: 22 $, $Date: 2008-10-29 10:39:53 -0200 (Wed, 29 Oct 2008) $
 *
 */
public class DigiconServiceException extends RuntimeException {

	private static final long serialVersionUID = 2324742359088894381L;

	public DigiconServiceException(String mensagem) {
		super(mensagem);
	}

	public DigiconServiceException(String mensagem, Throwable causa) {
		super(mensagem, causa);
	}

	public DigiconServiceException(Throwable causa) {
		super(causa);
	}

}