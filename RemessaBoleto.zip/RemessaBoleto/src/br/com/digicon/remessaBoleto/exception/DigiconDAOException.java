/**
 *
 */
package br.com.digicon.remessaBoleto.exception;

/**
 * Exception ocasionada por erros na camada DAO
 *
 * @author Daniel
 *
 */
public class DigiconDAOException extends DigiconException {

	private static final long serialVersionUID = 8893872357912927997L;

	public DigiconDAOException( String mensagem ){
		super( mensagem );
	}

	public DigiconDAOException( String mensagem, Throwable causa ){
		super( mensagem, causa );
	}

	public DigiconDAOException( Throwable causa ){
		super( causa );
	}
}
