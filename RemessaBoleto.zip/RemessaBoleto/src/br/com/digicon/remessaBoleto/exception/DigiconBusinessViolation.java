/**
 *
 */
package br.com.digicon.remessaBoleto.exception;

/**
 * Classe Throwable que deve ser lan�ada quando alguma regra de neg�cio n�o
 * estiver de acordo com o esperado na aplica��o. N�o se trata de uma exce��o,
 * apenas uma viola��o de regra de neg�cios.
 *
 * @author Daniel
 *
 */
public class DigiconBusinessViolation extends Throwable {

	public DigiconBusinessViolation(){
		super();
	}

	public DigiconBusinessViolation( String mensagem ){
		super( mensagem );
	}

	public DigiconBusinessViolation( String mensagem, Throwable causa ){
		super( mensagem, causa );
	}

	public DigiconBusinessViolation( Throwable causa ){
		super( causa );
	}

}
