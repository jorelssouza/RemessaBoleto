package br.com.digicon.remessaBoleto.exception;

/**
 *
 * @author renato
 * @author $Author: renato $
 * @version $Rev: 20 $, $Date: 2008-10-24 16:56:38 -0200 (Fri, 24 Oct 2008) $
 */
public class DigiconInvalidLoginException extends DigiconException {

	private static final long serialVersionUID = 110513565268336912L;

	public DigiconInvalidLoginException( String mensagem ){
		super( mensagem );
	}

	public DigiconInvalidLoginException( String mensagem, Throwable causa ){
		super( mensagem, causa );
	}

	public DigiconInvalidLoginException( Throwable causa ){
		super( causa );
	}

}
