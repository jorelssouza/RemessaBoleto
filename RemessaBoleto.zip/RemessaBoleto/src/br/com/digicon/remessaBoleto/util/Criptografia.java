package br.com.digicon.remessaBoleto.util;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

import br.com.digicon.remessaBoleto.exception.DigiconEncryptorException;

public class Criptografia {

	private Criptografia(){
	}

	private static StandardPBEStringEncryptor encryptor;

	static{
		encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword("Digic0n");
	}

	public static String encripta(String texto) throws DigiconEncryptorException{
		try{
			return encryptor.encrypt(texto);
		}
		catch(Exception e){
			throw new DigiconEncryptorException( "Convers�o inv�lida");
		}
	}

	public static String decripta(String texto) throws DigiconEncryptorException{
		try{
			return encryptor.decrypt(texto);
		}
		catch(Exception e){
			throw new DigiconEncryptorException( "Convers�o inv�lida");
		}
	}
}
