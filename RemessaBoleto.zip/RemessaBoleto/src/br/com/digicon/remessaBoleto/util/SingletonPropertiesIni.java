package br.com.digicon.remessaBoleto.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import org.apache.log4j.Logger;

public class SingletonPropertiesIni {
	
	private static Properties properties;
	private static final transient Logger LOG = Logger.getLogger(SingletonPropertiesIni.class);
	
    private SingletonPropertiesIni() {
    }
    
    public static Properties getProperties() {
        if (properties == null) {
        	properties = new Properties();
        	loadProperties();
        }
 
        return properties;
    }
    
    private static void loadProperties() {
    	try {
			properties.load(new FileInputStream("remessaBoleto.ini"));
		} catch (FileNotFoundException e) {
			LOG.error("Arquivo remessaBoleto.ini n�o encontrado.");
			e.printStackTrace();
		} catch (IOException e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
		}
    }

}
