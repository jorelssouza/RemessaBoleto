package br.com.digicon.remessaBoleto.util;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.beanutils.converters.DateTimeConverter;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;



import br.com.digicon.remessaBoleto.dao.SysParameterDAO;

public final class GeralUtility {
 
	private SysParameterDAO sysParameterDAO;
	public static final char DIREITA = '1';
	public static final char ESQUERDA = '2';

	private GeralUtility() {
	}

	public synchronized static String removeZeroAEsquerda(String texto) {
		StringBuffer novo = new StringBuffer();
		boolean removeZeroEsquerda = true;
		for (int i = 0; i < texto.length(); i++) {
			if (removeZeroEsquerda) {
				if (texto.charAt(i) != '0') {
					removeZeroEsquerda = false;
					novo.append(texto.charAt(i));
				}
			} else {
				novo.append(texto.charAt(i));
			}
		}
		return novo.toString();
	}
	
	public synchronized static boolean validaCpfCaracteresIguais(String cpf) {
		int c = 48; // equivale ao caracter 0 (ZERO)
		for (; c <= 58; c++) {
			int totalCaracteresIguais = 0;
			for (int i = 0, t = cpf.length(); i < t; i++) {
				if (cpf.charAt(i) == (char) c) {
					totalCaracteresIguais++;
				}
			}
			if (totalCaracteresIguais == cpf.length()) {
				return false;
			}
		}
		return true;
	}
	
	
	/**
	 * @return Boolean
	 */
	public static Boolean isSabadoDomingo(){
		
		Date data = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(data);  
		
		int day = cal.get(Calendar.DAY_OF_WEEK);
		
		if(day == 1 || day == 7 ){
			return true;
		}else{
			return false;
		}
	}
	
	
	/**
	 * Calcula quantidade maxima lote por arquivo
	 * @param variavel 
	 * @return Retorna long qtde Maxima de Lotes no arquivo 
	 */
	public synchronized static Long calcularQtdeMaxLotes(Long qtdeMaxBoletoPorLote){
		
		Long qtdMaxLote = 0L;
		Long auxCount = 2 * (qtdeMaxBoletoPorLote + 1);
		qtdMaxLote = 999997/auxCount;
		
		return qtdMaxLote;
	}

	/**
	 * Retorna true se uma String � nula ou vazia
	 *
	 * @param variavel
	 * @return Vari�vel l�gica com a valida��o
	 */
	public synchronized static boolean isEmpty(Object variavel) {
		boolean retorno = (variavel == null);
		if (!retorno) {
			if (variavel instanceof String) {
				retorno = (((String) variavel).trim().equals(""));
			}
		}
		return retorno;
	}

	/**
	 * L� um arquivo e retorno uma String com o seu conte�do, quebrado por linha
	 *
	 * @param Nome
	 *            do arquivo
	 * @return String com o conte�do do arquivo
	 * @throws IOException
	 */
	public synchronized static String getMensagemArquivo(String arquivo)
			throws IOException {
		StringBuffer result = new StringBuffer();

//		InputStream inputStream = DiscoveryResource.getInstance().search(
//				GeralUtility.class, arquivo);
//		if (inputStream != null) {
//			BufferedReader bufferedReader = new BufferedReader(
//					new InputStreamReader(inputStream));
//			String linha = null;
//			while ((linha = bufferedReader.readLine()) != null)
//				result.append(linha).append("\n");
//			inputStream.close();
//		}

		return result.toString();
	}

	/**
	 * Valida um CPF, que pode ser enviado com ou sem pontos e tra�o ex.
	 * 101.101.101-01 ou 10110110101 O m�todo remove os pontos e tra�os,
	 * preenche com zeros a esquerda para efetuar a valida��o.
	 *
	 * @param cpf
	 * @return true ou false
	 */
	public synchronized static Boolean validaCpf(String cpf) throws Exception {

		cpf = cpf.trim();
		String nDigVerific;
		String nDigResult;
		int d1, d2;
		int digito1, digito2, resto;
		int digitoCPF;

		try {
			if (!"".equals(cpf)) {
				cpf = cpf.replaceAll("-", "");
				cpf = cpf.replaceAll("[.]", "");
				cpf = GeralUtility.preencher(cpf, 11, '0', ESQUERDA);

				d1 = d2 = 0;
				digito1 = digito2 = resto = 0;
				for (int n_Count = 1; n_Count < cpf.length() - 1; n_Count++) {
					digitoCPF = Integer.valueOf(
							cpf.substring(n_Count - 1, n_Count)).intValue();
					d1 = d1 + (11 - n_Count) * digitoCPF;
					d2 = d2 + (12 - n_Count) * digitoCPF;
				}
				;
				resto = (d1 % 11);
				if (resto < 2)
					digito1 = 0;
				else
					digito1 = 11 - resto;
				d2 += 2 * digito1;
				resto = (d2 % 11);
				if (resto < 2)
					digito2 = 0;
				else
					digito2 = 11 - resto;
				nDigVerific = cpf.substring(cpf.length() - 2, cpf.length());
				nDigResult = String.valueOf(digito1) + String.valueOf(digito2);
			} else {
				return false;
			}
		} catch (Exception e) {
			throw new Exception("ERRADO !");
		}
		return nDigVerific.equals(nDigResult);
	}
	
	public synchronized static Boolean validaPisPasep(String pisPasep) {
		
		pisPasep = pisPasep.replaceAll("-", "");
		pisPasep = pisPasep.replaceAll("[.]", "");
		
        if (pisPasep.length() != 11)
            return false;
        String numDig = pisPasep.substring(0, 10);
        return Modulo11.obterDVBase10(numDig, false).equals(pisPasep.substring(10, 11));
		
	}

	/**
	 * Valida um CNPJ, que pode ser enviado com ou sem pontos e tra�o ex.
	 * 01.001.001/0001-01 ou 01001001000101 O m�todo remove os pontos,tra�os e
	 * barra, preenche com zeros a esquerda para efetuar a valida��o.
	 *
	 * @param cnpj
	 * @return true ou false
	 */
	public synchronized static Boolean validaCnpj(String cnpj) {

		cnpj = cnpj.replaceAll("[/]", "");
		cnpj = cnpj.replaceAll("[-]", "");
		cnpj = cnpj.replaceAll("[.]", "");
		cnpj = GeralUtility.preencher(cnpj, 14, '0', ESQUERDA);

		int soma = 0, dig;
		String cnpj_calc = cnpj.substring(0, 12);
		char[] chr_cnpj = cnpj.toCharArray();
		for (int i = 0; i < 4; i++)
			if (chr_cnpj[i] - 48 >= 0 && chr_cnpj[i] - 48 <= 9)
				soma += (chr_cnpj[i] - 48) * (6 - (i + 1));
		for (int i = 0; i < 8; i++)
			if (chr_cnpj[i + 4] - 48 >= 0 && chr_cnpj[i + 4] - 48 <= 9)
				soma += (chr_cnpj[i + 4] - 48) * (10 - (i + 1));
		dig = 11 - (soma % 11);
		cnpj_calc += (dig == 10 || dig == 11) ? "0" : Integer.toString(dig);
		soma = 0;
		for (int i = 0; i < 5; i++)
			if (chr_cnpj[i] - 48 >= 0 && chr_cnpj[i] - 48 <= 9)
				soma += (chr_cnpj[i] - 48) * (7 - (i + 1));
		for (int i = 0; i < 8; i++)
			if (chr_cnpj[i + 5] - 48 >= 0 && chr_cnpj[i + 5] - 48 <= 9)
				soma += (chr_cnpj[i + 5] - 48) * (10 - (i + 1));
		dig = 11 - (soma % 11);
		cnpj_calc += (dig == 10 || dig == 11) ? "0" : Integer.toString(dig);
		return cnpj.equals(cnpj_calc);
	}
	
	
	/**
	 * Transforma uma determinada String numa outra com um tamanho especificado,
	 * mantendo os valores ao lado direito da String.
	 * @param value
	 *            A string original
	 * @return String
	 */
	public static synchronized String removerStringEsquerda(String value, int tamanho) {

		String resultado = null;
		
		if(value != null){
			resultado = value.substring(value.length() - tamanho);
		}	
		
		return resultado;

	}
	
	/**
	 * Transforma uma determinada String numa outra com um tamanho especificado,
	 * preenchendo, se necess�rio, com um caracter especificado.
	 *
	 * @deprecated Utilize StringUtils.leftPad ou StringUtils.rightPad da
	 *             biblioteca Commons Lang.
	 * @param value
	 *            A string original
	 * @param tamanho
	 *            O tamanho da nova string, caso ela seja menor que a string
	 *            atual, a string atual ser� devolvida.
	 * @param preenchimento
	 *            O caracter que ser� usado para preencher o nova string �
	 *            esquerda.
	 * @param direcao
	 *            Dire��o do preenchimento (DIREITA/ESQUERDA)
	 * @return
	 */
	@Deprecated
	public static synchronized String preencherTamanho(Object value, int tamanho, char preenchimento, char direcao) {
		
		String valorTamanho = "";
		String valor;  
		
		if(value != null){
			
			valor = value.toString();
			
			if(tamanho < valor.length()){
				valorTamanho = valor.substring(0, tamanho);
			}else{
				valorTamanho = valor;
			}
		}

		if (direcao == ESQUERDA) {
			return StringUtils.leftPad(valorTamanho, tamanho, preenchimento);
			
		} else {
			return StringUtils.rightPad(valorTamanho, tamanho, preenchimento);
		}

	}
	
	/**
	 * Transforma uma determinada String numa outra com um tamanho especificado,
	 * preenchendo, se necess�rio, com um caracter especificado.
	 *
	 * @deprecated Utilize StringUtils.leftPad ou StringUtils.rightPad da
	 *             biblioteca Commons Lang.
	 * @param value
	 *            A string original
	 * @param tamanho
	 *            O tamanho da nova string, caso ela seja menor que a string
	 *            atual, a string atual ser� devolvida.
	 * @param preenchimento
	 *            O caracter que ser� usado para preencher o nova string �
	 *            esquerda.
	 * @param direcao
	 *            Dire��o do preenchimento (DIREITA/ESQUERDA)
	 * @return
	 */
	@Deprecated
	public static synchronized String preencher(String value, int tamanho,
			char preenchimento, char direcao) {

		if (direcao == ESQUERDA) {
			return StringUtils.leftPad(value, tamanho, preenchimento);
			
			
		} else {
			return StringUtils.rightPad(value, tamanho, preenchimento);
		}

		// StringBuffer buffer = new StringBuffer(255);
		//
		// if (direcao == ESQUERDA) {
		// buffer.append(value);
		// int offset = tamanho - value.length();
		// for (int i = 0; i < offset; i++)
		// buffer.insert(i, preenchimento);
		// } else {
		// buffer.append(value);
		// int offset = tamanho - value.length();
		// for (int i = 0; i < offset; i++)
		// buffer.append(preenchimento);
		// }
		// return buffer.toString();
	}

	public static synchronized String zeros(int tamanho) {
		return StringUtils.leftPad("", tamanho, '0');
	}

	public static synchronized String brancos(int tamanho) {
		return StringUtils.rightPad("", tamanho, ' ');
	}

	/**
	 * Valida um RG, que pode ser enviado com ou sem pontos e tra�o
	 *
	 * @param sRgNumber
	 * @param sRgDigit
	 * @param sRgEmittedState
	 * @param dtRgEmittedDt
	 * @return true ou false
	 */
	public synchronized static boolean validaRg(String sRgNumber,
			String sRgDigit, String sRgEmittedState, Date dtRgEmittedDt) {

		if (sRgNumber == null || sRgEmittedState == null
				|| dtRgEmittedDt == null) {
			return false;
		}

		sRgNumber = sRgNumber.replaceAll("[-]", "");
		sRgNumber = sRgNumber.replaceAll("[.]", "");

		Calendar cal = Calendar.getInstance();
		cal.setTime(dtRgEmittedDt);

		int iRgYear = cal.get(Calendar.YEAR);
		int iValidMinYear = 1987;
		int iRgNumberSize = 14;

		int iNumber = 0;
		int iWeight = 2;
		int iSum = 0;
		int iVerifDigit = 0;
		boolean bIsValidRg = false;

		sRgNumber = GeralUtility.preencher(sRgNumber, iRgNumberSize, '0',
				ESQUERDA);

		if ("SP".equals(sRgEmittedState) && iRgYear >= iValidMinYear) {
			for (int iPosition = (iRgNumberSize - 1); iPosition >= 0; iPosition--) {
				try {
					iNumber = Integer
							.parseInt("" + sRgNumber.charAt(iPosition));
				} catch (Exception e) {
					return false;
				}
				iSum += (iNumber * iWeight);
				iWeight++;
				if (iWeight == 10) {
					iWeight = 2;
				}
			}

			iVerifDigit = (iSum % 11);
			if ((String.valueOf(iVerifDigit).equalsIgnoreCase(sRgDigit.trim()))
					|| (iVerifDigit == 10 && sRgDigit.trim().equalsIgnoreCase(
							"X"))) {
				bIsValidRg = true;
			} else {
				bIsValidRg = false;
			}
		} else {
			bIsValidRg = true;
		}
		return bIsValidRg;
	}

	/**
	 * Truque para evitar cache de p�gina WEB.
	 *
	 * @param value
	 * @return
	 */
	public static final String antiPageCache(String value) {
		if (value == null || "".equals(value))
			return "";
		StringBuffer buffer = new StringBuffer();
		buffer.append(System.currentTimeMillis());
		buffer.append(RandomStringUtils.random(10, "123456789"));
		return String.format("%s?%s", value, buffer.toString());
	}

	public static final Date hoje() {
		Calendar hoje = GregorianCalendar.getInstance();
		hoje.set(Calendar.HOUR_OF_DAY, 0);
		hoje.set(Calendar.MINUTE, 0);
		hoje.set(Calendar.SECOND, 0);
		hoje.set(Calendar.MILLISECOND, 0);
		return hoje.getTime();
	}

	public static final Date DataAtual(Integer hh, Integer mm, Integer ss,
			Integer ms) {
		Calendar hoje = GregorianCalendar.getInstance();
		hoje.set(Calendar.HOUR_OF_DAY, hh);
		hoje.set(Calendar.MINUTE, mm);
		hoje.set(Calendar.SECOND, ss);
		hoje.set(Calendar.MILLISECOND, ms);
		return hoje.getTime();
	}

	public static final Date setaHorario(Date dt, Integer hh, Integer mm,
			Integer ss, Integer ms) {
		Calendar hour = GregorianCalendar.getInstance();
		hour.setTime(dt);
		hour.set(Calendar.HOUR_OF_DAY, hh);
		hour.set(Calendar.MINUTE, mm);
		hour.set(Calendar.SECOND, ss); 
		hour.set(Calendar.MILLISECOND, ms);
		return hour.getTime();
	}
	
	
	/**
	 * Converte java.util.Date para String HHMMSS , deve-se informar o Date 
	 *
	 * @param data
	 * @param pattern
	 *            (default = HHMMSS)
	 * @return String
	 */
	public static final String getHoraMinutoSegundo(Date dt) {
		
		String hhmmss = "";
		
		hhmmss += GeralUtility.preencher(Integer.toString(dt.getHours()), 2, '0', GeralUtility.ESQUERDA);  
		hhmmss += GeralUtility.preencher(Integer.toString(dt.getMinutes()), 2, '0', GeralUtility.ESQUERDA);
		hhmmss += GeralUtility.preencher(Integer.toString(dt.getSeconds()), 2, '0', GeralUtility.ESQUERDA);
		
		return hhmmss;
	}
	
	/**
	 * Remove TimeStamp String (9999-99-99 00:00:00.0)   para o formato DDMMAAAA
	 * @param String no formato 9999-99-99 00:00:00.0
	 * @return String no Formato DDMMAAAA
	 */
	public static String converteTimeStampSemBarraData(String data) {
		
		String dataCompleta = data.substring(0, 10);
		String ano = dataCompleta.substring(0, 4);
		String mes = dataCompleta.substring(5, 7);
		String dia = dataCompleta.substring(8, 10);		
		
		String result = dia+mes+ano;
		return result;
	}
	
	
	/**
	 * Converte Formato String DDMMAAAA para formato AAAAMMDD
	 * @param String no formato DDMMAAAA
	 * @return String no Formato AAAAMMDD
	 */
	public static String converteDataAnoMesDia(String data) {
		
		String dia = data.substring(0, 2);
		String mes = data.substring(2, 4);
		String ano = data.substring(4, 8);		
		
		String result = ano+mes+dia;
		return result;
	}
	
	
	
	/**
	 * Remove Barras da Data String (DD/MM/AAAA)   para o formato DDMMAAAA
	 * : dd/MM/yyyy
	 *
	 * @param String no formato DD/MM/AAAA
	 * @return String no Formato DDMMAAAA
	 */
	public static String removeBarraData(String data) {
		
		String dataSemBarra;
		
		dataSemBarra = data.substring(0, 2);
		dataSemBarra += data.substring(3, 5);
		dataSemBarra += data.substring(6, 10);
		
		return dataSemBarra;
	}
	


	
	
	
	
	
	
	
    public static boolean isDiaUtil (Date data, List<Date> feriados) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(data); 
             if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
                    return false;
             }
             if (isFeriado(data, feriados)) {
                    return false;
             }
             return true;
       }
       
       public static Date proxDiaUtil (List<Date> feriados) {
    	
    	   Date data = new Date();
    	   Calendar cal = Calendar.getInstance();
    	   cal.setTime(data);  
    	   cal.add(Calendar.DATE, 1);
    	   while (isDiaUtil(cal.getTime(), feriados) == false) {
    		   cal.add(Calendar.DATE, 1);
    	   }
        
            return cal.getTime();
       }
       

       public static boolean isFeriado (Date data, List<Date> feriados) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(data); 
             return (feriados == null ? false : feriados.contains(cal.getTime()));
       }

	
	
	
	
	
	
	
	

	/**
	 * Converte String para java.util.Date, deve-se informar o pattern, exemplo
	 * : dd/MM/yyyy
	 *
	 * @param data
	 * @param pattern
	 *            (default = dd/MM/yyyy)
	 * @return java.util.Date
	 */
	public static Date converteStringtoDate(String data, String pattern) {
		DateTimeConverter dc = new DateTimeConverter(java.util.Date.class);
		if (pattern == null) {
			pattern = "dd/MM/yyyy";
		}
		dc.setPattern(pattern);
		return (Date) dc.convert(java.util.Date.class, data);
	}

	public static final String convertDateToString(Date date, String pattern) {
		DateFormat dateFormat = new SimpleDateFormat(pattern, new Locale(
				"pt_BR"));
		return dateFormat.format(date);
	}

	public static final Date primeiroDiaMes() {
		DateTime dateTime = new DateTime(GeralUtility.hoje());
		return dateTime.dayOfMonth().withMinimumValue().toDate();
	}

	public static final Date ultimoDiaMes() {
		DateTime dateTime = new DateTime(GeralUtility.hoje());
		return dateTime.dayOfMonth().withMaximumValue().toDate();
	}

	/* Retorna em dias o intervalo de um determinado periodo */
	public static final Long intervaloDatas(Date dtini, Date dtfim) {
		if ((dtini != null) && (dtfim != null)) {
			return (dtfim.getTime() - dtini.getTime()) / 86400000;
		} else {
			return null;
		}
	}

	/**
	 *
	 * @param data
	 *            - Data utilizada como base para acr�scimo e decr�scimo de
	 *            anos.
	 * @param anosAntes
	 *            - N� de anos que ser�o decrementados.
	 * @param anosApos
	 *            - N� de anos que ser�o acrescentados.
	 * @return Lista Contendo anos.
	 */
	public static List<String> addAnosData(Date data, Integer anosAntes,
			Integer anosApos) {
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(data);

		List<String> listaAno = new ArrayList<String>();
		listaAno.add(GeralUtility.convertDateToString(data, "yyyy"));

		if (anosAntes != null && anosAntes.intValue() > 0) {
			for (int antes = 1; anosAntes.intValue() >= antes; antes++) {
				calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) - 1);
				listaAno.add(GeralUtility.convertDateToString(
						calendar.getTime(), "yyyy"));
			}
		}
		calendar.setTime(data);
		if (anosApos != null && anosApos.intValue() > 0) {
			for (int apos = 1; anosApos.intValue() >= apos; apos++) {
				calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) + 1);
				listaAno.add(GeralUtility.convertDateToString(
						calendar.getTime(), "yyyy"));
			}
		}

		Collections.sort(listaAno);
		Collections.reverse(listaAno);
		return listaAno;
	}

	/**
	 *
	 * Validar se h� apenas letras e n�meros a-z A-Z 0-9 (sem acentua��o)
	 *
	 * @param texto
	 *            - Texto para valida��o.
	 * @return true ou false
	 */
	public static boolean isLetrasNumeros(String texto) {
		Pattern p = Pattern.compile("[a-zA-Z0-9 ]+");
		Matcher m = p.matcher(texto);
		return m.matches();
	}

	/**
	 *
	 * Validar se h� apenas letras a-z A-Z (sem acentua��o)
	 *
	 * @param texto
	 *            - Texto para valida��o.
	 * @return true ou false
	 */
	public static boolean isLetras(String texto) {
		Pattern p = Pattern.compile("[a-zA-Z ]+");
		Matcher m = p.matcher(texto);
		return m.matches();
	}

	/**
	 *
	 * Validar se h� apenas n�meros 0-9
	 *
	 * @param texto
	 *            - Texto para valida��o.
	 * @return true ou false
	 */
	public static boolean isNumeros(String texto) {
		Pattern p = Pattern.compile("[0-9 ]+");
		Matcher m = p.matcher(texto);
		return m.matches();
	}

	/**
	 * Calcular a diferença de horas entre duas datas
	 * @param ini
	 * @param fim
	 * @return
	 */
	public static Integer calcularDiferencaHoras(Date ini, Date fim) {

		Calendar dtInicio = Calendar.getInstance();
		dtInicio.setTime(ini);

		Calendar dtFinal = Calendar.getInstance();
		dtFinal.setTime(fim);

		Integer horas = (int) ((dtFinal.getTimeInMillis() - dtInicio
				.getTimeInMillis()) / (60 * 60 * 1000));

		return horas;
	}
	
	

	
	
	public static String formatarCPF(String cpf) {
		StringBuffer aux = new StringBuffer();
		String retorno;
		
		// Remove qualquer caracter que n�o seja digito
		for (int k=0; k < cpf.length(); k++) {
			if (cpf.charAt(k) >= '0' && cpf.charAt(k) <= '9') {
				aux = aux.append(cpf.charAt(k));
			}
		}
		
		// Preenche a esquerda com zeros.
		for (int k=11; k > aux.length(); k--)
		{
			aux = (new StringBuffer()).append('0').append(aux);
		}
		retorno = aux.toString();

		// Coloca a formata��o padr�o para CPF onde esperado.
		aux = new StringBuffer();
		for (int k=0; k < retorno.length(); k++) {
			aux = aux.append(retorno.charAt(k));
			if (k==2 || k==5) {
				aux = aux.append('.');
			} else if (k==8) {
				aux = aux.append('-');
			};
		}
		
		retorno = aux.toString();
		return retorno;
	}
	
	public static String formatarPISPASEP(String pisPasep){

		if (pisPasep.length() != 11)
			return pisPasep;

		StringBuilder sb = new StringBuilder();
        sb.append(pisPasep.substring(0, 3));
        sb.append(".");
        sb.append(pisPasep.substring(3, 7));
        sb.append(".");
        sb.append(pisPasep.substring(7, 10));
        sb.append("-");
        sb.append(pisPasep.substring(10, 11));
        return sb.toString();
	}
	
	public static String formatarCNPJ(String cnpj) {
		StringBuffer aux = new StringBuffer();
		String retorno;
		
		// Remove qualquer caracter que n�o seja digito
		for (int k=0; k < cnpj.length(); k++) {
			if (cnpj.charAt(k) >= '0' && cnpj.charAt(k) <= '9') {
				aux = aux.append(cnpj.charAt(k));
			}
		}
		
		// Preenche a esquerda com zeros.
		for (int k=14; k > aux.length(); k--)
		{
			aux = (new StringBuffer()).append('0').append(aux);
		}
		retorno = aux.toString();

		// Coloca a formata��o padr�o para CNPJ onde esperado.
		aux = new StringBuffer();
		for (int k=0; k < retorno.length(); k++) {
			aux = aux.append(retorno.charAt(k));
			if (k==1 || k==4) {
				aux = aux.append('.');
			} else if (k==7) {
				aux = aux.append('/');
			} else if (k==11) {
				aux = aux.append('-');
			}
		}
		
		retorno = aux.toString();
		return retorno;
	}
	
	
	
	
	/**
	 * Efetua as seguintes normaliza��es para obten��o de certificados:
	 * Elimina acentos e cedilhas e caracteres speciais dos nomes
	 * @param str A string a normalizar.
	 * @return resultRet A string normalizada em maiusculo.
	 */
	public static String removeCaracteresEspeciais(String str) {
		char[] chars = str.toCharArray();
		StringBuffer ret = new StringBuffer(chars.length * 2);
		String resultRet;
		for (int i = 0; i < chars.length; ++i) {
			char aChar = chars[i];
			if (aChar == ' ' || aChar == '\t') {
				ret.append(' '); // convertido para espa�o
			} else if (aChar > ' ' && aChar < 256) {
				if (FIRST_CHAR[aChar - ' '] != ' ') {
					ret.append(FIRST_CHAR[aChar - ' ']); // 1 caracter
					
					
				}
				if (SECOND_CHAR[aChar - ' '] != ' ') {
					ret.append(SECOND_CHAR[aChar - ' ']); // 2 caracteres
				}
			}
		}
		
		resultRet = ret.toString();
		//retira caracteres speciais
		resultRet = resultRet.replaceAll("[^a-zA-Z0-9 ]", "");
		
		return resultRet.toUpperCase();
	}
	
	
	/**
	 * Insere Qtde de Casas Decimais conforme desejado
	 * @param casas
	 * @param valor
	 * @return BigDecimal
	 */
	public static BigDecimal casasDecimais(int casas, BigDecimal valor) {
		
		valor = valor.setScale(casas, RoundingMode.HALF_UP);
	    
	    return valor; 
	}    
	
	
	
	
	/** Para a normaliza��o dos caracteres de 32 a 255, primeiro caracter */
	private static final char[] FIRST_CHAR = 
			(" !'#$%&'()*+\\-./0123456789:;<->?@ABCDEFGHIJKLMNOPQRSTUVWXYZ" 
	        + "[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~ E ,f'.++^%S<O Z  ''''.-" 
			+ "-~Ts>o ZY !C#$Y|$'(a<--(_o+23'u .,1o>113?AAAAAAACEEEEIIIIDNOO"	
	        + "OOOXOUUUUyTsaaaaaaaceeeeiiiidnooooo/ouuuuyty").toCharArray();

	/** Para a normaliza��o dos caracteres de 32 a 255, segundo caracter */
	private static final char[] SECOND_CHAR = 
			("  '         ,                                               " 
			+ "\\                                   $  r'. + o  E      ''  " + "  M  e     #  =  'C.<  R .-..     ..>424     E E            " 
			+ "   E E     hs    e e         h     e e     h ").toCharArray();
	
	
  /**
    * Calculo do Modulo 11 para geracao do digito verificador
    * de boletos bancarios 
    * Observa��es:
    *   - Exemplo de uso: getMod11(nossoNumero, 9,1)
    *   - 9 e 1 s�o fixos de acordo com a base
    * @param   num: string num�rica para a qual se deseja calcularo digito verificador
    *          base: valor maximo de multiplicacao [2-$base]
    *          r: quando especificado um devolve somente o resto
	* @return  Retorna o Digito verificador.
    */
	
    public static int getMod11(String num, int base, int r){
       
        base = 9;
        r    = 0;
        int soma = 0;
        int fator = 2;
        String[] numeros,parcial;
        numeros = new String[num.length()+1];
        parcial = new String[num.length()+1];
        /* Separacao dos numeros */
        for (int i = num.length(); i > 0; i--) {
            // pega cada numero isoladamente
            numeros[i] = num.substring(i-1,i);
            // Efetua multiplicacao do numero pelo falor
            parcial[i] = String.valueOf(Integer.parseInt(numeros[i]) * fator);
            // Soma dos digitos
            soma += Integer.parseInt(parcial[i]);
            if (fator == base) {
                // restaura fator de multiplicacao para 2
                fator = 1;
            }
            fator++;
        }
        /* Calculo do modulo 11 */
        if (r == 0) {
            soma *= 10;
            int digito = soma % 11;
            if (digito == 10) {
                digito = 0;
            }
            return digito;
        } else {
            int resto = soma % 11;
            return resto;
        }
    }
	
	
	private static class Modulo11 {  
		
        public static String obterDVBase10 (String fonte, boolean dezPorX) {
            char subUm = '0';
            if (dezPorX) {
                    subUm = 'X';
            }
            return obterDVBaseParametrizada(fonte, 10, '0', subUm);         
        }
        
        public static String obterDVBaseParametrizada (String fonte, int base, char subZero, char subUm) {
	        //validarFonte(fonte);
	        int peso = 2;
	        int dv = 0;
	        for (int i = fonte.length() - 1; i >= 0; i--) {
	                dv += Integer.parseInt(fonte.substring(i, i + 1)) * peso;
	                if (peso == base - 1) {
	                        peso = 2;
	                } else {
	                        peso++;
	                }
	        }
	        dv = dv % 11;
	        if (dv > 1) {
	                return String.valueOf(11 - dv);
	        } else if (dv == 1) {
	                return String.valueOf(subUm);
	        }
	        return String.valueOf(subZero);
        
        }
	}
	



	
	public SysParameterDAO getSysParameterDAO() {
		return sysParameterDAO;
	}

	public void setSysParameterDAO(SysParameterDAO sysParameterDAO) {
		this.sysParameterDAO = sysParameterDAO;
	}
	
	
	
}
