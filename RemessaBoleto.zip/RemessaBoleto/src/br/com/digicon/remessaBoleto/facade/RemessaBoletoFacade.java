package br.com.digicon.remessaBoleto.facade;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.List;
import org.apache.log4j.Logger;
import org.jboleto.JBoletoBean;
import br.com.digicon.remessaBoleto.constants.RemessaBoletoConstantes;
import br.com.digicon.remessaBoleto.util.GeralUtility;
import br.com.digicon.remessaBoleto.vo.BoletosEmitidosVO;
import br.com.digicon.remessaBoleto.vo.ParamRemessaBoletoVO;

public class RemessaBoletoFacade {
	
	private ParamRemessaBoletoVO parametros;
	
	private Long NSA;
	
	private Long numLote;
	
	private Long numRemessa;
	
	private Long contadorRegLotePQ;
	
	private Long numeroSequencialRegLoteP;
	
	private Long numeroSequencialRegLoteQ;
	
	private String nomeArquivo;
	
	private String sistema;
	
	private static final transient Logger LOG = Logger.getLogger(RemessaBoletoFacade.class);
	
	public void remessa(ParamRemessaBoletoVO param, Long NSA, List<JBoletoBean> boletos, List<BoletosEmitidosVO> listAux ,String sistema)throws Exception {
		
		
		
		//Cria o arquivo de remessa propriamente dito
		this.parametros = param;
		this.NSA = NSA;
		this.numLote = 0001L;
		this.numRemessa = NSA;
		this.contadorRegLotePQ = 0L;
		this.numeroSequencialRegLoteP = 2L;
		this.numeroSequencialRegLoteQ = 0L;
		this.sistema = sistema;
		
		StringBuffer linhaRemessa = new StringBuffer();
		
		linhaRemessa.append(this.buildHeader()); 
		
		linhaRemessa.append(System.getProperty("line.separator"));
		
		linhaRemessa.append(this.buildLote());
		
		linhaRemessa.append(System.getProperty("line.separator"));
		
		// Enviar Detalhes do Boleto para SegmentoP
		 for(int i=0; i<boletos.size();i++ ){

			BoletosEmitidosVO auxValidacao = listAux.get(i);
			JBoletoBean boleto = boletos.get(i);
			
			this.numeroSequencialRegLoteP++;
			linhaRemessa.append(this.buildSegmentoP(boleto, auxValidacao));
			linhaRemessa.append(System.getProperty("line.separator"));
			
			this.numeroSequencialRegLoteP++;
			this.numeroSequencialRegLoteQ++;
			linhaRemessa.append(this.buildSegmentoQ(boleto, auxValidacao));
			linhaRemessa.append(System.getProperty("line.separator"));
		}
		
		linhaRemessa.append(this.buildTrailerLote());

		linhaRemessa.append(System.getProperty("line.separator"));
		
		linhaRemessa.append(this.buildTrailerHeader());   
		
        this.parametros.setNomeArquivo(this.montarNomeArquivo());		

         //gravar StringBuffer linhaRemessa em .txt
       	this.gravarArquivoRemessa(this.parametros.getNomeArquivo(), linhaRemessa, true);
        	
		
	};
	
	/** 
	 * Monta o 4.1 Header do Arquivo 
	 */
	private String buildHeader() throws Exception {
		
		try{
			
			// Gera o tipo de registro 0 (header de arquivo) da remessa 
			StringBuffer linha = new StringBuffer();
			
			// [1-3]: Codigo do Banco na Compensacao - Num(3)
			linha.append(GeralUtility.preencherTamanho(this.parametros.codBancoCompensacao, 3, '0', GeralUtility.ESQUERDA));
			
			// [4-7]: Lote de Servi�o - Num(4) 
			linha.append("0000");
			
			// [8-8]: Tipo de registro - Num(1)
			linha.append(RemessaBoletoConstantes.TIPO_REGISTRO_HEADER);
			
			// [9-17]: Uso Exclusivo FEBRABAN/CNAB : Alfa(9)
			linha.append(GeralUtility.brancos(9));
			
			// [18-18]: Tipo de Inscri��o da Empresa : Num(1)
			linha.append(RemessaBoletoConstantes.TIPO_INSCRICAO_SPTRANS);
			
			// [19-32]: N�mero de Inscri��o da Empresa : Num(14)
			linha.append(GeralUtility.preencherTamanho(this.parametros.getNumeroInscricaoEmpresa(), 14, '0', GeralUtility.ESQUERDA));
			
			// [33-52]: Uso Exclusivo da Caixa : Num(20)
			linha.append(GeralUtility.zeros(20));
			
			// [53-57]: Ag�ncia Mantenedora da Conta : Num(5)
			linha.append(GeralUtility.preencherTamanho(this.parametros.agencia, 5, '0', GeralUtility.ESQUERDA));
			
			// [58-58]: Digito Verificador da Ag�ncia: Alfa(1)
			linha.append(GeralUtility.preencherTamanho(this.parametros.dvAgencia, 1, ' ', GeralUtility.DIREITA));
			
			if(this.sistema.equalsIgnoreCase("SCA")){
	
				// [59-64]: C�digo do Conv�nio no Banco: Num(6)
				linha.append(GeralUtility.preencherTamanho(this.parametros.codigoCedente, 6, '0', GeralUtility.ESQUERDA));
				
			}else{
				
				// [59-64]: C�digo do Conv�nio no Banco: Num(6)
				linha.append(GeralUtility.preencherTamanho(this.parametros.codigoCedente, 6, '0', GeralUtility.ESQUERDA));	
			}
			
			// [65-71]: Uso Exclusivo CAIXA : Num(7)
			linha.append(GeralUtility.zeros(7));
			
			// [72-72]: Uso Exclusivo CAIXA : Num(1)
			linha.append("0");
			
			// [73-102]: Nome da Empresa : Alfa(30)
			linha.append(GeralUtility.preencherTamanho(GeralUtility.removeCaracteresEspeciais(this.parametros.nomeCedente.toString()), 30, ' ', GeralUtility.DIREITA));
					
			// [103-132]: Nome do Banco : Alfa(30)
			linha.append(GeralUtility.preencherTamanho(GeralUtility.removeCaracteresEspeciais(this.parametros.nomeBanco.toString()), 30, ' ', GeralUtility.DIREITA));
			
			// [133-142]: Uso Exclusivo FEBRABAN/CNAB : Alfa(10)
			linha.append(GeralUtility.brancos(10));
			
			// [143-143]: C�digo Remessa : Num(1)
			linha.append(RemessaBoletoConstantes.CODIGO_REMESSA);
			
			// [144-151]: Data de Gera��o do Arquivo : Num(8)
			linha.append(GeralUtility.preencherTamanho(this.parametros.dataGeracaoArquivo, 8, '0', GeralUtility.ESQUERDA));
			
			// [152-157]: Hora de Gera��o do Arquivo : Num(6)
			linha.append(GeralUtility.preencherTamanho(this.parametros.horaGeracao, 6, '0', GeralUtility.ESQUERDA));
			
			// [158-163]: NSA : Num(6)
			linha.append(GeralUtility.preencherTamanho(this.numRemessa, 6, '0', GeralUtility.ESQUERDA));
			
			// [164-166]: Num da vers�o do layout do Arquivo: Num(3)
			linha.append(RemessaBoletoConstantes.VERSAO_LAYOUT_ARQUIVO_REMESSA);
			
			// [167-171]: Densidade de Grava��o do Arquivo: Num(5)
			linha.append(GeralUtility.zeros(5));
			
			// [172-191]: Para uso Reservado do Banco : Alfa(20)
			linha.append(GeralUtility.brancos(20));
			
			// [192-211]: Para uso reservado da Empresa: Alfa(20)
			linha.append(GeralUtility.preencherTamanho(RemessaBoletoConstantes.FASE_REMESSA_PRODUCAO, 20, ' ', GeralUtility.DIREITA));
			
			// [212-215]: Vers�o Aplicativo Caixa: Alfa(4)
			linha.append(GeralUtility.brancos(4));
			
			// [216-240]: Uso Exclusivo FEBRABAN/CNAB: Alfa(25)
			linha.append(GeralUtility.brancos(25));
	
			return linha.toString();
		
		}catch (Exception e){
			LOG.error(e.getMessage());
			LOG.error("Erro ao Montar 4.1 Header do Arquivo");
			throw new Exception("Erro ao Montar 4.1 Header do Arquivo");
		}	

		
	};
	
	
	/** 
	 * Monta o 4.2 Trailer do Arquivo 
	 */
	private String buildTrailerHeader() throws Exception {
		
		try{
		
			// Gera o tipo de registro 0 (trailer do arquivo) da remessa 
			StringBuffer linha = new StringBuffer();
			
			// [1-3]: Codigo do Banco na Compensacao - Num(3)
			linha.append(GeralUtility.preencherTamanho(this.parametros.codBancoCompensacao, 3, '0', GeralUtility.ESQUERDA));
			
			// [4-7]: Lote de Servi�o - Num(4) 
			linha.append("9999");
			
			// [8-8]: Tipo de registro - Num(1)
			linha.append(RemessaBoletoConstantes.TIPO_REGISTRO_TRAILER_HEADER);
			
			// [9-17]: Uso Exclusivo FEBRABAN/CNAB : Alfa(9)
			linha.append(GeralUtility.brancos(9));
			
			// [18-23]: Quantidade de Lotes do Arquivo : Num(6)
			//linha.append(GeralUtility.preencherTamanho(this.parametros.qtdeLotesArquivo, 6, '0', GeralUtility.ESQUERDA));
			linha.append(GeralUtility.preencherTamanho("1", 6, '0', GeralUtility.ESQUERDA));
			
			// [24-29]: Quantidade de Registros do Arquivo : Num(6)
			linha.append(GeralUtility.preencherTamanho(this.parametros.qtdeRegistrosArquivo, 6, '0', GeralUtility.ESQUERDA));
			
			// [30-35]: Uso Exclusivo Fenabran/CNAB : Alfa(6)
			linha.append(GeralUtility.brancos(6));
			
			// [36-240]: Uso Exclusivo Fenabran/CNAB : Alfa(205)
			linha.append(GeralUtility.brancos(205));
			
			return linha.toString();
		
		}catch (Exception e){
			LOG.error(e.getMessage());
			LOG.error("Erro ao Montar 4.2 Trailer do Arquivo ");
			throw new Exception("Erro ao Montar 4.2 Trailer do Arquivo");
		}	

	};
	
	
	
	/** 
	 * Monta o 4.3 Header do Lote
	 */
	private String buildLote() throws Exception {
		
		try{
			// Gera o tipo de registro 0 (header do lote) da remessa 
			
			StringBuffer linha = new StringBuffer();
			
			// [1-3]: Codigo do Banco na Compensacao - Num(3)
			linha.append(GeralUtility.preencherTamanho(this.parametros.codBancoCompensacao, 3, '0', GeralUtility.ESQUERDA));
			
			// [4-7]: Lote de Servi�o - Num(4) 
			linha.append(GeralUtility.preencherTamanho(this.numLote, 4, '0', GeralUtility.ESQUERDA)); //sempre 1 lote por arquivo
			
			// [8-8]: Tipo de registro - Num(1)
			linha.append(RemessaBoletoConstantes.TIPO_REGISTRO_LOTE);
			
			// [9-9]: Tipo de Opera��o : Alfa(1)
			linha.append(RemessaBoletoConstantes.CODIGO_TIPO_OPERACAO);
			
			// [10-11]: Tipo de Servi�o : Num(2)
			linha.append(RemessaBoletoConstantes.CODIGO_TIPO_SERVICO);
			
			// [12-13]: Uso Exclusivo Fenabran/CNAB : Num(2)
			linha.append(GeralUtility.zeros(2));
			
			// [14-16]: N�mero da Vers�o do Layout do Lote : Num(3)
			linha.append(RemessaBoletoConstantes.CODIGO_NUMERO_VERSAO_LAYOUT);
			
			// [17-17]: Uso Exclusivo Fenabran/CNAB : Alfa(1)
			linha.append(GeralUtility.brancos(1));
			
			// [18-18]: Tipo de Inscri��o da Empresa: Num(1)
			linha.append(RemessaBoletoConstantes.CODIGO_TIPO_INSCRICAO_EMPRESA);
			
			// [19-33]: N�mero de Inscri��o da Empresa: Num(15)
			linha.append(GeralUtility.preencherTamanho(this.parametros.numeroInscricaoEmpresa, 15, '0', GeralUtility.ESQUERDA));
			
	//		if(this.sistema.equalsIgnoreCase("SCA")){
	//			// [34-39]: C�digo do Cedente no Banco : Num(6)
	//			linha.append(GeralUtility.preencherTamanho("852133", 6, '0', GeralUtility.ESQUERDA));			
	//		}else{
	
			// [34-39]: C�digo do Cedente no Banco : Num(6)
			linha.append(GeralUtility.preencherTamanho(this.parametros.codigoCedente, 6, '0', GeralUtility.ESQUERDA));
			
	//		}
			
			// [40-53]: Uso Exclusivo CAIXA : Num(14)
			linha.append(GeralUtility.zeros(14));
			
			// [54-58]: Ag�ncia Mantenedora da Conta : Num(5)
			linha.append(GeralUtility.preencherTamanho(this.parametros.agencia, 5, '0', GeralUtility.ESQUERDA));
			
			// [59-59]: Digito Verificador da Ag�ncia : Alfa(1)
			linha.append(GeralUtility.preencherTamanho(this.parametros.dvAgencia, 1, '0', GeralUtility.ESQUERDA));
			
			// [60-65]: C�digo do Conv�nio no Banco : Num(6)
			linha.append(GeralUtility.preencherTamanho(this.parametros.codigoCedente, 6, '0', GeralUtility.ESQUERDA));
			
			// [66-72]: C�digo do Modelo Personalizado : Num(7)
			linha.append(GeralUtility.zeros(7));
			
			// [73-73]: Uso Exclusivo Caixa : Num(1)
			linha.append(GeralUtility.zeros(1));
			
			// [74-103]: Nome da Empresa : Alfa(30)
			linha.append(GeralUtility.preencherTamanho(this.parametros.nomeEmpresa, 30, ' ', GeralUtility.DIREITA));
			
			// [104-143]: Mensagem 1 : Alfa(40)
			linha.append(GeralUtility.preencherTamanho(this.parametros.mensagem1, 40, ' ', GeralUtility.DIREITA));     
			
			// [144-183]: Mensagem 2: Alfa(40)
			linha.append(GeralUtility.preencherTamanho(this.parametros.mensagem2, 40, ' ', GeralUtility.DIREITA));    
			
			// [184-191]: N�mero Remessa/Retorno: Num(8)
			linha.append(GeralUtility.preencherTamanho(this.numRemessa, 8, '0', GeralUtility.ESQUERDA)); //� O N�MERO NSA
			
			// [192-199]: Data de Grava��o Remessa/Retorno: Num(8)
			linha.append(GeralUtility.preencherTamanho(this.parametros.dataGeracaoArquivo, 8, '0', GeralUtility.ESQUERDA));
			
			// [200-207]: Data do Cr�dito: Num(8)
			linha.append(GeralUtility.zeros(8));
			
			// [208-240]: Uso Exclusivo Febraban/CNAB: Alfa(33)
			linha.append(GeralUtility.brancos(33));
			
			return linha.toString();
		
		}catch (Exception e){
			LOG.error(e.getMessage());
			LOG.error("Erro ao Montar 4.3 Header do Lote");
			throw new Exception("Erro ao Montar 4.3 Header do Lote");
		}	
	
		
	};
	
	/** 
	 * Monta o 4.4 Detalhe do Segmento P
	 */
	private String buildSegmentoP(JBoletoBean boleto, BoletosEmitidosVO auxValidacao) throws Exception{   
	
		
		try{

			// gera o segmento P de um boleto especifico
			StringBuffer linha = new StringBuffer();
			
			this.contadorRegLotePQ++;
			
			// [1-3]: Codigo do Banco na Compensacao - Num(3)
			linha.append(GeralUtility.preencherTamanho(this.parametros.codBancoCompensacao, 3, '0', GeralUtility.ESQUERDA));
			
			// [4-7]: Lote de Servi�o - Num(4) 
			linha.append(GeralUtility.preencherTamanho(this.numLote, 4, '0', GeralUtility.ESQUERDA));
			
			// [8-8]: Tipo de registro - Num(1)
			linha.append(RemessaBoletoConstantes.TIPO_REGISTRO_SEGMENTO_P);
			
			// [9-13]: N�mero Sequencial do Registro no Lote : Num(5)
			linha.append(GeralUtility.preencherTamanho(this.contadorRegLotePQ, 5, '0', GeralUtility.ESQUERDA));
			
			// [14-14]: C�digo Segmento do Registro no Lote : Alfa(1)
			linha.append(RemessaBoletoConstantes.CODIGO_SEGMENTO_REGISTRO_LOTE_P);
			
			// [15-15]: Uso Exclusivo FEBRABAN/CNAB : Alfa(1)
			linha.append(GeralUtility.brancos(1));		
			
			// [16-17]: C�digo de Movimento Remessa : Num(2)
			linha.append(RemessaBoletoConstantes.CODIGO_MOVIMENTO_REMESSA);				
			
			// [18-22]: Ag�ncia Mantenedora da Conta : Num(5)
			linha.append(GeralUtility.preencherTamanho(this.parametros.agencia, 5, '0', GeralUtility.ESQUERDA));
			
			// [23-23]: Digito Verificador da Ag�ncia : Alfa(1)
			linha.append(GeralUtility.preencherTamanho(this.parametros.dvAgencia, 1, ' ', GeralUtility.DIREITA));
	
			// [24-29]: C�digo do Conv�nio no Banco: Num(6)
			linha.append(GeralUtility.preencherTamanho(this.parametros.codigoCedente, 6, '0', GeralUtility.ESQUERDA));
			
			// [30-37]: Uso Exclusivo CAIXA : Num(8)
			linha.append(GeralUtility.zeros(8));
			
			// [38-40]: Uso Exclusivo CAIXA : Num(3)
			linha.append(GeralUtility.zeros(3));	
			
			// [41-42]: Modalidade da Carteira : Num(2)
			linha.append(RemessaBoletoConstantes.CODIGO_MODALIDADE_CARTEIRA);	
			
			
			if(this.sistema.equalsIgnoreCase("LV")){
				
				if(boleto.getNossoNumero() != null){
					
					if(boleto.getNossoNumero().length() > 15){
						// [43-57]:Identifica��o do T�tulo no Banco : Num(15)
						linha.append(GeralUtility.preencherTamanho(GeralUtility.removerStringEsquerda(boleto.getNossoNumero(), 15), 15, '0', GeralUtility.ESQUERDA));		
					}else{
						// [43-57]:Identifica��o do T�tulo no Banco : Num(15)
						//linha.append(GeralUtility.preencherTamanho(boleto.getNoDocumento(), 15, '0', GeralUtility.ESQUERDA));
						linha.append(GeralUtility.preencherTamanho(boleto.getNossoNumero(), 15, '0', GeralUtility.ESQUERDA));
					}
				}	
	
			}else{
				
				if(boleto.getNossoNumero() != null){
					if(boleto.getNossoNumero().length() > 15){
						
						// [43-57]:Identifica��o do T�tulo no Banco : Num(15)
						linha.append(GeralUtility.preencherTamanho(GeralUtility.removerStringEsquerda(boleto.getNossoNumero(), 15), 15, '0', GeralUtility.ESQUERDA));   	
					}else{
						// [43-57]:Identifica��o do T�tulo no Banco : Num(15)
						linha.append(GeralUtility.preencherTamanho(boleto.getNossoNumero(), 15, '0', GeralUtility.ESQUERDA)); 	
					}
				}
			}
			
			// [58-58]:C�digo da Carteira : Num(1)
			linha.append(RemessaBoletoConstantes.CODIGO_CARTEIRA);			
			
			// [59-59]:Forma de Cadastramento do T�tulo no Banco : Num(1)
			linha.append(RemessaBoletoConstantes.CODIGO_FORMA_CADASTRAMENTO_TITULO_BANCO);			
			
			// [60-60]:Tipo de Documento : Alfa(1)
			linha.append(RemessaBoletoConstantes.CODIGO_TIPO_DOCUMENTO);					
	
			// [61-61]: Identifica��o da Emiss�o do Bloqueto : Num(1)
			linha.append(RemessaBoletoConstantes.CODIGO_IDENTIFICACAO_EMISSAO_BLOQUETO);					
			
			// [62-62]: Identifica��o da Entrega do Bloqueto : Alfa(1)
			linha.append(RemessaBoletoConstantes.CODIGO_IDENTIFICACAO_ENTREGA_BLOQUETO);	
			
			if(boleto.getNoDocumento() != null){
				
				if(boleto.getNoDocumento().length() > 11){
					// [63-73]: N�mero do Documento de Cobran�a : Alfa(11)
					linha.append(GeralUtility.preencherTamanho(GeralUtility.removerStringEsquerda(boleto.getNoDocumento(), 11), 11, ' ', GeralUtility.DIREITA));	 
					
				}else{
					// [63-73]: N�mero do Documento de Cobran�a : Alfa(11)
					linha.append(GeralUtility.preencherTamanho(boleto.getNoDocumento(), 11, ' ', GeralUtility.DIREITA));	 							
				}
			}	
			
			// [74-77]: Uso Exclusivo Caixa : Alfa(4)
			linha.append(GeralUtility.brancos(4));									
			
			
			if(this.sistema.equalsIgnoreCase("LV")){
				// [78-85]: Data de Vencimento do T�tulo : Num(8)
				linha.append(GeralUtility.preencherTamanho(GeralUtility.converteTimeStampSemBarraData(boleto.getDataVencimento().toString()), 8, '0', GeralUtility.ESQUERDA));
			}else{
				// [78-85]: Data de Vencimento do T�tulo : Num(8)
				linha.append(GeralUtility.preencherTamanho(GeralUtility.removeBarraData(boleto.getDataVencimento().toString()), 8, '0', GeralUtility.ESQUERDA));			
			}
			
			// [86-100]: Valor Nominal do T�tulo : Num(13,2)
			
			BigDecimal valor = new BigDecimal(boleto.getValorBoleto());
			linha.append(GeralUtility.preencherTamanho(GeralUtility.removeCaracteresEspeciais(GeralUtility.casasDecimais(2,valor).toString()), 15, '0', GeralUtility.ESQUERDA));	
			
			// [101-105]: Ag�ncia Encarregada da Cobran�a : Num(5)
			linha.append(GeralUtility.zeros(5));											
			
			// [106-106]: Digito Verificador da Ag�ncia : Num(1)
			linha.append(GeralUtility.zeros(1));													
			
			// [107-108]:Esp�cie do T�tulo : Num(2)
			linha.append(RemessaBoletoConstantes.CODIGO_ESPECIE_TITULO);
			
			// [109-109]:Identifica��o de T�tulo Aceito/N�o Aceito :Alfa(1)
			linha.append(RemessaBoletoConstantes.CODIGO_IDENTIFICACAO_TITULO);
			
			
			if(this.sistema.equalsIgnoreCase("LV")){
				// [110-117]:Data da Emiss�o do T�tulo :Num(8)
				linha.append(GeralUtility.preencherTamanho(GeralUtility.converteTimeStampSemBarraData(boleto.getDataDocumento().toString()), 8, '0', GeralUtility.ESQUERDA));
				
			}else{
				// [110-117]:Data da Emiss�o do T�tulo :Num(8)
				linha.append(GeralUtility.preencherTamanho(GeralUtility.removeBarraData(boleto.getDataProcessamento().toString()), 8, '0', GeralUtility.ESQUERDA));
			}
			
			// [118-118]:C�digo do Juros de Mora :Num(1)
			linha.append(RemessaBoletoConstantes.CODIGO_JUROS_MORA);		
			
			// [119-126]:Data do Juros de Mora :Num(8)
			linha.append(GeralUtility.zeros(8));		
			
			// [127-141]:Juros de Mora por Dia/Taxa :Num(13,2)
			linha.append(GeralUtility.zeros(15));				
			
			// [142-142]:C�digo do Desconto 1 :Num(1)
			linha.append(RemessaBoletoConstantes.CODIGO_DESCONTO);						
			
			// [143-150]:Data do Desconto 1 :Num(8)
			linha.append(GeralUtility.zeros(8));								
			
			// [151-165]:Valor/Percentual a ser Concedido :Num(13,2)
			linha.append(GeralUtility.zeros(15));										
			
			// [166-180]:Valor do IOF a ser Recolhido :Num(13,2)
			linha.append(GeralUtility.preencherTamanho(this.parametros.valorIof, 15, '0', GeralUtility.ESQUERDA));												
				
			// [181-195]:Valor do Abatimento :Num(13,2)
			linha.append(GeralUtility.zeros(15));												
			
			// [196-220]:Identifica��o do T�tulo na Empresa :Alfa(25)
			linha.append(GeralUtility.preencherTamanho(boleto.getNoDocumento(), 25, ' ', GeralUtility.DIREITA));	 															
			
			// [221-221]:C�digo para Protesto :Num(1)
			linha.append(RemessaBoletoConstantes.CODIGO_PROTESTO);	
			
			// [222-223]:N�mero de Dias para Protesto:Num(2)
			linha.append(GeralUtility.zeros(2));	
			
			// [224-224]:C�digo para Baixa/Devolu��o:Num(1)
			linha.append(RemessaBoletoConstantes.CODIGO_BAIXA_DEVOLUCAO);
			
			// [225-227]:N�mero de Dias para Baixa/Devolu��o :Alfa(3)
			linha.append(GeralUtility.preencherTamanho(this.parametros.qtdeDiasDevolucao, 3, '0', GeralUtility.ESQUERDA));	
			
			// [228-229]:C�digo da Moeda :Num(2)
			linha.append(RemessaBoletoConstantes.CODIGO_MOEDA);	
			
			// [230-239]:Uso Exclusivo Caixa :Num(10)
			linha.append(GeralUtility.zeros(10));			
			
			// [240-240]:Uso Exclusico Febraban/CNAB :Alfa(1)
			linha.append(GeralUtility.brancos(1));					
			
			return linha.toString(); 
		
		}catch (Exception e){
			LOG.error(e.getMessage());
			LOG.error("Erro ao Montar 4.4 Detalhe do Segmento P");
			throw new Exception("Erro ao Montar 4.4 Detalhe do Segmento P");
		}	
		
	};
	
	

	/** 
	 * Monta o 4.5 Detalhe do Segmento Q
	 */
	private String buildSegmentoQ(JBoletoBean boleto, BoletosEmitidosVO auxValidacao) throws Exception  {   

		
		try{
			//gera o segmento Q de um boleto especifico
			StringBuffer linha = new StringBuffer();
			
			this.contadorRegLotePQ++;
			
			// [1-3]: Codigo do Banco na Compensacao - Num(3)
			linha.append(GeralUtility.preencherTamanho(this.parametros.codBancoCompensacao, 3, '0', GeralUtility.ESQUERDA));
			
			// [4-7]: Lote de Servi�o - Num(4) 
			linha.append(GeralUtility.preencherTamanho(this.numLote, 4, '0', GeralUtility.ESQUERDA));
			
			// [8-8]: Tipo de registro - Num(1)
			linha.append(RemessaBoletoConstantes.TIPO_REGISTRO_SEGMENTO_Q);
			
			// [9-13]: N�mero Sequencial do Registro no Lote : Num(5)
			linha.append(GeralUtility.preencherTamanho(this.contadorRegLotePQ, 5, '0', GeralUtility.ESQUERDA));
			
			// [14-14]: C�digo Segmento do Registro no Lote : Alfa(1)
			linha.append(RemessaBoletoConstantes.CODIGO_SEGMENTO_REGISTRO_LOTE_Q);
			
			// [15-15]: Uso Exclusivo FEBRABAN/CNAB : Alfa(1)
			linha.append(GeralUtility.brancos(1));		
			
			// [16-17]: C�digo de Movimento Remessa : Num(2)
			linha.append(RemessaBoletoConstantes.CODIGO_MOVIMENTO_REMESSA);		
			
			// [18-18]: Tipo de Inscri��o da Empresa : Num(1)
			try{
				if(this.sistema.equalsIgnoreCase("LV")){   
					if(auxValidacao.getTipoPessoa().equalsIgnoreCase("J")){
						
						linha.append(RemessaBoletoConstantes.TIPO_INSCRICAO_SACADO_CNPJ);
						
					}else if(auxValidacao.getTipoPessoa().equalsIgnoreCase("F")){
						
						linha.append(RemessaBoletoConstantes.TIPO_INSCRICAO_SACADO_CPF);
					}	
				}else if(this.sistema.equalsIgnoreCase("SCA")){
		
					linha.append(RemessaBoletoConstantes.TIPO_INSCRICAO_SACADO_CPF);
					
				}else if(this.sistema.equalsIgnoreCase("VCW")){
					if(auxValidacao.getTipoPessoa().equalsIgnoreCase("2")){
						
						linha.append(RemessaBoletoConstantes.TIPO_INSCRICAO_SACADO_CNPJ);
						
					}else if(auxValidacao.getTipoPessoa().equalsIgnoreCase("1")){
						
						linha.append(RemessaBoletoConstantes.TIPO_INSCRICAO_SACADO_CPF);
					}	
				}
			
			} catch (Exception e) {
				LOG.error(e.getMessage());
				LOG.error(e.getStackTrace());
				LOG.error("Erro ao Verificar Tipo Pessoa no Sistema:"+ this.sistema);	
			}
			
			try{
				// [19-33]: N�mero de Inscri��o : Num(15)
				linha.append(GeralUtility.preencherTamanho(boleto.getCpfSacado(), 15, '0', GeralUtility.ESQUERDA));   //CPF SACADO
				
			} catch (Exception e){
				LOG.error(e.getMessage());
				LOG.error(e.getStackTrace());
				LOG.error("Erro ao Obter CPF/CNPJ do Sacado no Sistema:"+ this.sistema);
			}
			
			try{
				// [34-73]: Nome do Sacado: Alfa(40)
				linha.append(GeralUtility.preencherTamanho(boleto.getNomeSacado(), 40, ' ', GeralUtility.DIREITA));
				
			} catch (Exception e){
				LOG.error(e.getMessage());
				LOG.error(e.getStackTrace());
				LOG.error("Erro ao Obter Nome do Sacado no Sistema:"+ this.sistema);
			}	


			try{
				if(boleto.getEnderecoSacado() != null & boleto.getEnderecoSacado().length()>0){
					// [74-113]: Endere�o do Sacado: Alfa(40)
					linha.append(GeralUtility.preencherTamanho(boleto.getEnderecoSacado(), 40, ' ', GeralUtility.DIREITA));
				}else{
					// [74-113]: Endere�o do Sacado: Alfa(40)
					linha.append(GeralUtility.preencherTamanho(this.parametros.enderecoSacadoPadrao, 40, ' ', GeralUtility.DIREITA));
				}
				
			} catch (Exception e){
				LOG.error(e.getMessage());
				LOG.error(e.getStackTrace());
				LOG.error("Erro ao Obter Endereco do Sacado no Sistema:"+ this.sistema);
				// [74-113]: Endere�o do Sacado: Alfa(40)
				linha.append(GeralUtility.preencherTamanho(this.parametros.enderecoSacadoPadrao, 40, ' ', GeralUtility.DIREITA));
			}
			
			try{
			
				if(boleto.getBairroSacado() != null & boleto.getBairroSacado().length()>0){
					// [114-128]: Bairro do sacado : Alfa(15)
					linha.append(GeralUtility.preencherTamanho(boleto.getBairroSacado(), 15, ' ', GeralUtility.DIREITA));
				}else{
					// [114-128]: Bairro do sacado : Alfa(15)
					linha.append(GeralUtility.preencherTamanho(this.parametros.bairroSacadoPadrao, 15, ' ', GeralUtility.DIREITA));			
				}
				
			} catch (Exception e){
				LOG.error(e.getMessage());
				LOG.error(e.getStackTrace());
				LOG.error("Erro ao Obter Bairro do Sacado no Sistema:"+ this.sistema);
				// [114-128]: Bairro do sacado : Alfa(15)
				linha.append(GeralUtility.preencherTamanho(this.parametros.bairroSacadoPadrao, 15, ' ', GeralUtility.DIREITA));			
			}	
				
			String cep = "";
			String sufCep = "";  
			
			try{
				if(boleto.getCepSacado() != null & boleto.getCepSacado().length()>0){
					if(this.sistema.equalsIgnoreCase("SA")){
						cep = boleto.getCepSacado().substring(0, 5);
						sufCep = boleto.getCepSacado().substring(6, 9);
						
				     }if(this.sistema.equalsIgnoreCase("LV")){
				    	String tmpCep = ("00000000"+boleto.getCepSacado().trim());
				    	tmpCep = tmpCep.substring(tmpCep.length() - 8);
						cep = tmpCep.substring(0, 5);
						sufCep = tmpCep.substring(5, 8);
				     }else{
						cep = boleto.getCepSacado().substring(0, 5);
						sufCep = boleto.getCepSacado().substring(6, 9);
				     }
				}else{
					cep = this.parametros.cepSacadoPadrao.toString();
					sufCep = this.parametros.sufixoCepSacadoPadrao.toString();
				}
			
			} catch (Exception e) {
				
				LOG.error(e.getMessage());
				LOG.error(e.getStackTrace());
				LOG.error("Erro ao Obter CEP no Sistema:"+ this.sistema);
				
				cep = this.parametros.cepSacadoPadrao.toString();
				sufCep = this.parametros.sufixoCepSacadoPadrao.toString();
			}	
	
			// [129-133]: CEP do Sacado : Num(5)
			linha.append(GeralUtility.preencherTamanho(cep, 5, '0', GeralUtility.ESQUERDA));	
			
			// [134-136]: Sufixo do CEP do Sacado: Num(3)
			linha.append(GeralUtility.preencherTamanho(sufCep, 3, '0', GeralUtility.ESQUERDA));
			
			
		   try{
				if(boleto.getCidadeSacado() != null & boleto.getCidadeSacado().length()>0){
					// [137-151]:Cidade do Sacado : Alfa(15)
					linha.append(GeralUtility.preencherTamanho(boleto.getCidadeSacado(), 15, ' ', GeralUtility.DIREITA));
				}else{
					// [137-151]:Cidade do Sacado : Alfa(15)
					linha.append(GeralUtility.preencherTamanho(this.parametros.cidadeSacadoPadrao, 15, ' ', GeralUtility.DIREITA));
				}
				
			} catch (Exception e){
				LOG.error(e.getMessage());
				LOG.error(e.getStackTrace());
				LOG.error("Erro ao Obter Cidade do Sacado  no Sistema:"+ this.sistema);
				// [137-151]:Cidade do Sacado : Alfa(15)
				linha.append(GeralUtility.preencherTamanho(this.parametros.cidadeSacadoPadrao, 15, ' ', GeralUtility.DIREITA));
			} 
			
		   try{
				if(boleto.getUfSacado() != null & boleto.getUfSacado().length()>0){
					// [152-153]:Unidade da Federa��o do Sacado : Alfa(2)
					linha.append(GeralUtility.preencherTamanho(boleto.getUfSacado(), 2, ' ', GeralUtility.DIREITA));
				}else{
					// [152-153]:Unidade da Federa��o do Sacado : Alfa(2)
					linha.append(GeralUtility.preencherTamanho(this.parametros.ufSacadoPadrao, 2, ' ', GeralUtility.DIREITA));
				}
		   } catch (Exception e){
				LOG.error(e.getMessage());
				LOG.error(e.getStackTrace());
				LOG.error("Erro ao Obter UF do Sacado  no Sistema:"+ this.sistema);
				// [152-153]:Unidade da Federa��o do Sacado : Alfa(2)
				linha.append(GeralUtility.preencherTamanho(this.parametros.ufSacadoPadrao, 2, ' ', GeralUtility.DIREITA));
		   }
	
			// [154-154]:Tipo de Inscri��o do Avalista : Num(1)
			linha.append(GeralUtility.zeros(1));			
			
			// [155-169]:N�mero de Inscri��o do Avalista : Num(15)
			linha.append(GeralUtility.zeros(15));
	
			// [170-209]:Nome do Avalista : Alfa(40)
			linha.append(GeralUtility.brancos(40));					
			
			// [210-212]:Banco Correspondente : Num(3)
			linha.append(GeralUtility.brancos(3));							
			
			// [213-232]:Nosso N�mero no Banco Correspondente : Alfa(20)
			linha.append(GeralUtility.brancos(20));									
			
			// [233-240]:Uso Exclusivo Febraban/CNAB : Alfa(8)
			linha.append(GeralUtility.brancos(8));										
			
			return linha.toString();  
		
		}catch (Exception e){
			LOG.error(e.getMessage());
			LOG.error(e.getStackTrace());
			LOG.error("Erro ao Montar 4.5 Detalhe do Segmento Q");
			throw new Exception("Erro ao Montar 4.5 Detalhe do Segmento Q");
		}
		
	};
	


	/** 
	 * Monta o 4.6 Trailer do Lote
	 */
	private String buildTrailerLote() throws Exception {
		
		try{
			// Gera o tipo de registro 0 (trailer do lote) da remessa 
			StringBuffer linha = new StringBuffer();
			
			// [1-3]: Codigo do Banco na Compensacao - Num(3)
			linha.append(GeralUtility.preencherTamanho(this.parametros.codBancoCompensacao, 3, '0', GeralUtility.ESQUERDA));
			
			// [4-7]: Lote de Servi�o - Num(4) 
			linha.append(GeralUtility.preencherTamanho(this.numLote.toString(), 4, '0', GeralUtility.ESQUERDA));
			
			// [8-8]: Tipo de registro - Num(1)
			linha.append(RemessaBoletoConstantes.TIPO_REGISTRO_TRAILER_LOTE);
			
			// [9-17]: Uso exclusivo FEBRABAN/CNAB : Alfa(9)
			linha.append(GeralUtility.brancos(9));
			
			// [18-23]: Quantidade de Registro no Lote : Num(6)  	G057 - Somat�ria da qtd de registro de tipo 1,3,5
			//linha.append(GeralUtility.preencherTamanho(this.parametros.qtdeRegistrosLote, 6, '0', GeralUtility.ESQUERDA));
			linha.append(GeralUtility.preencherTamanho(numeroSequencialRegLoteP, 6, '0', GeralUtility.ESQUERDA));
			
			// [24-29]: Quantidade de T�tulos em Cobran�a : Num(6)
			linha.append(GeralUtility.zeros(6));
			
			// [30-46]: Valor Total dos T�tulos em Cobran�a : Num(15,2)
			linha.append(GeralUtility.zeros(17));
			
			// [47-52]: Quantidade de T�tulos em Cobran�a Caucionada: Num(6)
			linha.append(GeralUtility.zeros(6));
			
			// [53-69]: Valor Total dos T�tulos em Cobran�a : Num(15,2)
			linha.append(GeralUtility.zeros(17));
			
			// [70-75]: Quantidade de T�tulos em Cobran�a Descontada: Num(6)
			linha.append(GeralUtility.zeros(6));
			
			// [76-92]: Valor Total dos T�tulos em Cobran�a Descontada : Num(15,2)
			linha.append(GeralUtility.zeros(17));
			
			// [93-123]: Uso Exclusivo Fenabran/CNAB : Alfa(31)
			linha.append(GeralUtility.brancos(31));
			
			// [124-240]: Uso Exclusivo Fenabran/CNAB : Alfa(117)
			linha.append(GeralUtility.brancos(117));
			
			return linha.toString();
		
		}catch (Exception e){
			LOG.error(e.getMessage());
			LOG.error("Erro ao Montar 4.6 Trailer do Lote");
			throw new Exception("Erro ao Montar 4.6 Trailer do Lote");
		}	
			
		
	}

	
	private String montarNomeArquivo() throws Exception{
		
		try{
				this.nomeArquivo = "RM";
				
				//C�digo do sistema 
				this.nomeArquivo += GeralUtility.preencherTamanho(this.sistema, this.sistema.length(), ' ', GeralUtility.DIREITA);
				
				//C�digo do banco cedente
				this.nomeArquivo += GeralUtility.preencherTamanho(this.parametros.codBancoCompensacao, 3, '0', GeralUtility.ESQUERDA);
				
				//C�digo do cedente
				this.nomeArquivo += GeralUtility.preencherTamanho(this.parametros.codigoCedente, 6, '0', GeralUtility.ESQUERDA);
				
				//C�digo do n�mero de remessa (NSA)
				this.nomeArquivo += GeralUtility.preencherTamanho(this.numRemessa, 6, '0', GeralUtility.ESQUERDA);
				
				//Data de gera��o do arquivo
				this.nomeArquivo += GeralUtility.preencherTamanho(GeralUtility.converteDataAnoMesDia(this.parametros.dataGeracaoArquivo.toString()), 8, '0', GeralUtility.ESQUERDA);
				
				//Data de gera��o do arquivo
				this.nomeArquivo += GeralUtility.preencherTamanho(this.parametros.horaGeracao, 6, '0', GeralUtility.ESQUERDA);
				
				this.nomeArquivo += ".txt";
				
				return this.nomeArquivo;
	
		}catch (Exception e){
			LOG.error(e.getMessage());
			LOG.error("Erro ao Nomear Arquivo de Remessa.");
			throw new Exception("Erro ao Nomear Arquivo de Remessa.");
		}	
				
	}
		
	private void gravarArquivoRemessa(String nomeArquivo, StringBuffer linhaRemessa,  boolean append) throws Exception, IOException{
		
		 LOG.info("Iniciando Gravacao de Arquivo...");	

		 //Gravar no local definido na tabela SYS_PARAMETER
		 File arquivo = null; 
		 
		 if(this.sistema.equalsIgnoreCase("VCW")){
			 
			 if(this.parametros.codigoCedenteVcwComum.equalsIgnoreCase(this.parametros.codigoCedente.toString())){
				 
				 arquivo = new File(this.parametros.caminhoGravacaoArquivoVcwComum, nomeArquivo);
				 //arquivo = new File("D:\\arquivoRemessa" + "\\" + this.sistema + "\\" + GeralUtility.preencherTamanho(this.parametros.caminhoGravacaoArquivoVcwComum.toString(), 6, '0', GeralUtility.ESQUERDA), nomeArquivo); 
			 }
			 
			 if(this.parametros.codigoCedenteVcwEstudante.equalsIgnoreCase(this.parametros.codigoCedente.toString())){
				 
				 arquivo = new File(this.parametros.caminhoGravacaoArquivoVcwEst, nomeArquivo);
				 //arquivo = new File("D:\\arquivoRemessa" + "\\" + this.sistema + "\\" + GeralUtility.preencherTamanho(this.parametros.codigoCedenteVcwEstudante.toString(), 6, '0', GeralUtility.ESQUERDA), nomeArquivo);
			 }			 
		 }else{
			 
			 arquivo = new File(this.parametros.caminhoGravacaoArquivo , nomeArquivo);
		 }
		 
//Descomentar para Teste
//File arquivoTeste = new File("D:\\arquivoRemessa" + "\\" + this.sistema + "\\" + GeralUtility.preencherTamanho(this.parametros.codigoCedente.toString(), 6, '0', GeralUtility.ESQUERDA), nomeArquivo);
		 this.parametros.setPathArquivo(arquivo.getPath());
		 
	       try{
	            FileWriter grava = new FileWriter(arquivo, append);
	            PrintWriter escreve = new PrintWriter(grava);
	            escreve.println(linhaRemessa);
	            escreve.close();
	            grava.close();
	            
	            LOG.info("Gravacao de Arquivo Finalizada.");
	            
	        }catch (IOException ex) {
	        	LOG.error(ex.getMessage());
				LOG.error("Erro ao Gravar Arquivo de Remessa.");
				ex.printStackTrace();
				throw new IOException("Erro ao Gravar Arquivo de Remessa:" + ex.getMessage());
				
	        }
	}
	
	
	public ParamRemessaBoletoVO getParametros() {
		return parametros;
	}

	
	public void setParametros(ParamRemessaBoletoVO parametros) {
		this.parametros = parametros;
	}
	
	public Long getNSA() {
		return NSA;
	}

	public void setNSA(Long nSA) {
		NSA = nSA;
	}

}
