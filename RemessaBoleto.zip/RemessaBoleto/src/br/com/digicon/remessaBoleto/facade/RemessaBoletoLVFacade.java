package br.com.digicon.remessaBoleto.facade;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang.BooleanUtils;
import org.apache.log4j.Logger;
import org.jboleto.JBoletoBean;
import br.com.digicon.remessaBoleto.dao.BoletosEmitidosDAO;
import br.com.digicon.remessaBoleto.dao.ParametroLVDAO;
import br.com.digicon.remessaBoleto.dao.SysParameterDAO;
import br.com.digicon.remessaBoleto.util.GeralUtility;
import br.com.digicon.remessaBoleto.vo.BoletosEmitidosVO;
import br.com.digicon.remessaBoleto.vo.ParamRemessaBoletoVO;
import br.com.digicon.remessaBoleto.vo.SysParameterVO;
import br.com.digicon.remessaBoleto.vo.ValoresDominioVO;

public class RemessaBoletoLVFacade {
	
	public RemessaBoletoFacade remessaBoletoFacade;
	
	private SysParameterDAO sysParameterDAO;
	
	private ParametroLVDAO parametroLVDAO;
	
	private ParamRemessaBoletoVO param;
	
	private BoletosEmitidosDAO boletosEmitidosDAO;
	
	private List<JBoletoBean> jBoletoBeanLista;
	
	private List<Date> listaFeriados;
	
	private List<BoletosEmitidosVO> boletos;
	
	private List<BoletosEmitidosVO> boletosTotal;
	
	private static final transient Logger LOG = Logger.getLogger(RemessaBoletoSAFacade.class);
	
	public void processarRemessa() {
				
		//Obtem os dados que ser�o usados na remessa, logs de processamento e controle do que j� foi ou n�o emitido
		this.param = new ParamRemessaBoletoVO();
		this.param.setDataInicioProcesso(new Date());
		
		//trava Objeto Para Garantir �nica Execu��o de Gera��o de Arquivo   
		//this.parametroLVDAO.travarObjetoRemessaLV("FALSE");
		
		//Obtem os dados tabela SPTRANSLV.PARAMETRO 
		List <SysParameterVO> listaParametros = this.parametroLVDAO.findAll();
		
		//4.1 Header do Arquivo		
		for(int i=0;i<listaParametros.size();i++){
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_LOCK_REMESSA")){
				this.param.setLockObjeto(BooleanUtils.toBooleanObject(listaParametros.get(i).getParameterValue()));
			}				
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_CODIGO_BANCO")){
				this.param.setCodBancoCompensacao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}	
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_AGENCIA")){
				this.param.setAgencia(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}					
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_CODIGO_CEDENTE")){
				this.param.setCodigoCedente(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}	
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_CPF_CNPJ_SPTRANS")){
				this.param.setNumeroInscricaoEmpresa(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}	
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_MENSAGEM_1")){
				this.param.setMensagem1(listaParametros.get(i).getParameterValue());
			}	
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_MENSAGEM_2")){
				this.param.setMensagem2(listaParametros.get(i).getParameterValue());
			}	
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_NOME_CEDENTE")){
				this.param.setNomeCedente(listaParametros.get(i).getParameterValue());
				this.param.setNomeEmpresa(listaParametros.get(i).getParameterValue());
			}	
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_NOME_BANCO_CEDENTE")){
				this.param.setNomeBanco(listaParametros.get(i).getParameterValue());
			}	
						
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_VALOR_IOF")){
				this.param.setValorIof(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}	
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_QTD_DIAS_DEVOLUCAO")){
				this.param.setQtdeDiasDevolucao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_QTD_MAX_DIAS_VENCIMENTO")){
				this.param.setQtdeMaxDiasVenc(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_QTD_MAX_POR_LOTE")){
				this.param.setQtdeLotesArquivo(GeralUtility.calcularQtdeMaxLotes(Long.parseLong(listaParametros.get(i).getParameterValue())));
			}
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_DTINICIO_REGISTRO")){
				this.param.setDataConsultaBoleto(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_DIRETORIO_GRAVACAO_REMESSA_LV")){
				this.param.setCaminhoGravacaoArquivo(listaParametros.get(i).getParameterValue());
			}		
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_PADRAO_ESTADO")){
				this.param.setUfSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_PADRAO_CIDADE")){
				this.param.setCidadeSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_PADRAO_ENDERECO")){
				this.param.setEnderecoSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_PADRAO_BAIRRO")){
				this.param.setBairroSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_PADRAO_CEP")){
				this.param.setCepSacadoPadrao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_BOLETO_PADRAO_SUFIXOCEP")){
				this.param.setSufixoCepSacadoPadrao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}	
			
			if(listaParametros.get(i).getParameterName().equals("PARAM_QTDE_MAX_REG_ARQUIVO_REMESSA")){
				this.param.setQtdeMaxBoletosArquivo(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}	
			
		}
		
		// Verifica o Lock da Remessa LV 
		if(!this.param.getLockObjeto()){
			
			try {
			
				//trava Objeto Para Garantir �nica Execu��o de Gera��o de Arquivo   
				this.parametroLVDAO.processarTravaObjetoRemessaLV("TRUE");
		
				this.param.setDvAgencia(GeralUtility.getMod11(Long.toString(param.getAgencia()), 9, 1));
		
				Date hoje = GeralUtility.hoje();
				String dateAtual = GeralUtility.convertDateToString(hoje, "dd/MM/yyyy");
				String dateGeracaoArquivo = GeralUtility.convertDateToString(hoje, "ddMMyyyy");
				
				Boolean isFeriado = (this.parametroLVDAO.getFeriadosLV(hoje).size() > 0);
				Boolean isSabadoDomingo = GeralUtility.isSabadoDomingo();
	    
				//Data Gera��o formato: DD/MM/YYYY
				this.param.setDataGeracao(dateAtual);
				//Data Gera��o formato: DDMMYYYY
				this.param.setDataGeracaoArquivo(dateGeracaoArquivo);
	    
				Date hora = new Date();
				String strHoraGeracao = ""; 
				strHoraGeracao = GeralUtility.getHoraMinutoSegundo(hora);
	    
				//Hora Gera��o formato: HHMMSS
				this.param.setHoraGeracao(strHoraGeracao);
				
				this.listaFeriados   = new ArrayList<Date>();
				this.boletos = new ArrayList<BoletosEmitidosVO>();
				this.boletosTotal = new ArrayList<BoletosEmitidosVO>();
				
				this.listaFeriados = this.parametroLVDAO.getListaFeriadosLV();
				//Date proxDiaUtil = GeralUtility.proxDiaUtil(this.listaFeriados);
			    //Date dataParametro = GeralUtility.converteStringtoDate(this.param.getDataConsultaBoleto(), "dd/MM/yyyy");
				Date diaAtual = GeralUtility.hoje();
				
			    LOG.info("Consultando Boletos LV...");
			    
			    //if(proxDiaUtil.before(dataParametro)){
			    //this.boletos = parametroLVDAO.listaBoletos(dataParametro);	
			    //}else{
			    
			   	this.boletosTotal = parametroLVDAO.searchBoletos(diaAtual);
			   	//Utilizacao do parametro para limitar quantidade de boletos por arquivo de remessa
			   	int qtde = this.boletosTotal.size();
			   	int j = 1;
			   	for(int i=0; i<this.param.getQtdeMaxBoletosArquivo(); i++){
			   		if(qtde >= j){    
			   			this.boletos.add(this.boletosTotal.get(i));
			   			j++;
			   		}else{
			   			break;
			   		}
			   	}
			   	
			   	//}
			    
			    LOG.info("Fim da Consulta Boletos LV...");
			    
//REMOVER AO ENTREGAR!!!!! (05/06/2004)
//this.boletos = parametroLVDAO.listaBoletos(GeralUtility.converteStringtoDate("16/12/2015", "dd/MM/yyyy"));
			    
			    if(this.boletos.size()>0){
			    
					//C�digo NSA (Numero Remessa)
					Long NSA = parametroLVDAO.obterNumeroNSA();		
	
					this.param.setDataGravacao(dateAtual);
					this.param.setQtdeRegistrosLote(2L + (this.boletos.size() * 2));
					this.param.setQtdeRegistrosArquivo(4L + (this.boletos.size() * 2));
				 	this.param.setNumeroRemessa(NSA);
				 	
				 	Integer tamanhoLista = this.boletos.size();
					this.param.setQtdeBoletosArquivo(Long.parseLong(tamanhoLista.toString()));
					
					this.jBoletoBeanLista = new ArrayList<JBoletoBean>();
					
					for(int i=0; i<this.boletos.size(); i++){
						JBoletoBean jBoleto = new JBoletoBean();
						jBoleto = this.boletos.get(i).getjBoleto();
						jBoleto.setNossoNumero(this.boletos.get(i).getNossoNumero().toString());
						jBoletoBeanLista.add(jBoleto);
					}
					if(!isFeriado & !isSabadoDomingo){
					
						this.insertAtualizarStatusGeracaoInicio("StatusProcRemessaBoleto", "Iniciado");
						
						try{
							//Solicita a gera��o do arquivo de remessa 
							this.remessaBoletoFacade.remessa(this.param, NSA, this.jBoletoBeanLista, this.boletos, "LV");
							
							// Atualizar status da gera��o	
							this.updateStatusGeracaoFim("StatusProcRemessaBoleto", "Sucesso");	
						
							//Atualizar informa��es do boleto ao gerar remessa, na tabela sptranslv.boleto
							this.updateBoletos(this.param.getArquivoId());	
							
						} catch (Exception e){
							LOG.info(e.getMessage());
							this.parametroLVDAO.processarTravaObjetoRemessaLV("FALSE");
							this.updateStatusGeracaoFim("ErroProcRemessaBoleto", "Erro");
							LOG.error(e.getMessage());
							LOG.error("Erro ao Efetuar Remessa.");	
							LOG.error(e.getStackTrace());
							e.printStackTrace();
						}	
					}
					
					//Destravar Objeto Para Garantir �nica Execu��o de Gera��o de Arquivo 
					this.parametroLVDAO.processarTravaObjetoRemessaLV("FALSE");
				
			    }else{
					//Destravar Objeto Para Garantir �nica Execu��o de Gera��o de Arquivo 
					this.parametroLVDAO.processarTravaObjetoRemessaLV("FALSE");
			    	LOG.info("SEM DADOS DE BOLETOS PARA GERACAO DE REMESSA!");
			    }	
			
			} catch (Exception e) {
				LOG.info(e.getMessage());
				this.parametroLVDAO.processarTravaObjetoRemessaLV("FALSE");
				LOG.error(e.getMessage());
				LOG.error("Erro ao Efetuar Remessa.");
				LOG.error(e.getStackTrace());
				e.printStackTrace();
			}
		
		}else{
			// Gerar LOG
			LOG.info("Remessa Boleto LV COM LOCK PARA OUTRA EXECUCAO.");
		}
		
	}
	
	
	public void updateBoletos(Long arquivoId){
		
		for(int i=0; i<this.boletos.size();i++ ){
			this.boletos.get(i).setArquivoRemessaId(arquivoId);
			this.parametroLVDAO.updateFlagBoletoRemessaLV(this.boletos.get(i));
		}
	}	
	
	

	public void insertAtualizarStatusGeracaoInicio(String domainName, String itemName){

		//Atualizar status da gera��o
		ValoresDominioVO dominio = new ValoresDominioVO();
		dominio.setDomainName(domainName);
		dominio.setItemName(itemName);
		dominio = this.sysParameterDAO.findByDominioItemRemessa(dominio);
		
		//sequence SPTRANSLV.SEQ_CTR_REMESSA_BOLETO
		this.param.setProcessoId(this.param.getNumeroRemessa());
		this.param.setDataFimProcesso(null);
		this.param.setDataInicioProcesso(new Date());
		this.param.setCodStatus(dominio.getCodeNumber());
		this.param.setCodigoErro(dominio.getCodeNumber());
		this.param.setMensagemErro(dominio.getDescription());
		
		//SPTRANSLV.TB_CTR_REMESSA_BOLETO 
		this.parametroLVDAO.insertContrRemessaLV(this.param); //insert
		
        //sequence SPTRANSLV.SEQ_DETALHE_REMESSA_BOLETO    
		this.param.setArquivoId(this.parametroLVDAO.getProcessoDetalheIdLV());
		this.param.setDataInicioGeracao(new Date());
		this.param.setDataAlteracao(null);
		
		//SPTRANSLV.TB_DETALHE_REMESSA_BOLETO
		this.parametroLVDAO.insertContrRemessaDetalhesLV(this.param);
	}
	
	
	public void updateStatusGeracaoFim(String domainName, String itemName){

		//Atualizar status da gera��o
		ValoresDominioVO dominio = new ValoresDominioVO();
		dominio.setDomainName(domainName);
		dominio.setItemName(itemName);
		dominio = this.sysParameterDAO.findByDominioItemRemessa(dominio);
		
		//sequence SPTRANSLV.SEQ_CTR_REMESSA_BOLETO
		this.param.setProcessoId(this.param.getNumeroRemessa());
		this.param.setDataInicioProcesso(this.param.getDataInicioProcesso());
	    this.param.setDataFimProcesso(new Date());
		this.param.setCodStatus(dominio.getCodeNumber());
		this.param.setCodigoErro(dominio.getCodeNumber());
		this.param.setMensagemErro(dominio.getDescription());
		
		//SPTRANSLV.TB_CTR_REMESSA_BOLETO 
		this.parametroLVDAO.updateContrRemessaLV(this.param);
		
        //sequence SPTRANSLV.SEQ_DETALHE_REMESSA_BOLETO    
		//this.param.setArquivoId(this.parametroLVDAO.obterProcessoDetalheIdLV());
		this.param.setDataAlteracao(new Date());
		
		//SPTRANSLV.TB_DETALHE_REMESSA_BOLETO
		this.parametroLVDAO.updateContrRemessaDetalhesLV(this.param);
	}
	
	
	

	public ParametroLVDAO getParametroLVDAO() {
		return parametroLVDAO;
	}


	public void setParametroLVDAO(ParametroLVDAO parametroLVDAO) {
		this.parametroLVDAO = parametroLVDAO;
	}


	public SysParameterDAO getSysParameterDAO() {
		return sysParameterDAO;
	}

	public void setSysParameterDAO(SysParameterDAO sysParameterDAO) {
		this.sysParameterDAO = sysParameterDAO;
	}


	public RemessaBoletoFacade getRemessaBoletoFacade() {
		return remessaBoletoFacade;
	}


	public void setRemessaBoletoFacade(RemessaBoletoFacade remessaBoletoFacade) {
		this.remessaBoletoFacade = remessaBoletoFacade;
	}


	public List<BoletosEmitidosVO> getBoletos() {
		return boletos;
	}

	public void setBoletos(List<BoletosEmitidosVO> boletos) {
		this.boletos = boletos;
	}

	public List<BoletosEmitidosVO> getBoletosTotal() {
		return boletosTotal;
	}

	public void setBoletosTotal(List<BoletosEmitidosVO> boletosTotal) {
		this.boletosTotal = boletosTotal;
	}

	public BoletosEmitidosDAO getBoletosEmitidosDAO() {
		return boletosEmitidosDAO;
	}

	public void setBoletosEmitidosDAO(BoletosEmitidosDAO boletosEmitidosDAO) {
		this.boletosEmitidosDAO = boletosEmitidosDAO;
	}


	public ParamRemessaBoletoVO getParam() {
		return param;
	}


	public void setParam(ParamRemessaBoletoVO param) {
		this.param = param;
	}
	
	public List<JBoletoBean> getjBoletoBeanLista() {
		return jBoletoBeanLista;
	}

	public void setjBoletoBeanLista(List<JBoletoBean> jBoletoBeanLista) {
		this.jBoletoBeanLista = jBoletoBeanLista;
	}

	public List<Date> getListaFeriados() {
		return listaFeriados;
	}

	public void setListaFeriados(List<Date> listaFeriados) {
		this.listaFeriados = listaFeriados;
	}
	
}
