package br.com.digicon.remessaBoleto.facade;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang.BooleanUtils;
import org.apache.log4j.Logger;
import org.jboleto.JBoletoBean;
import br.com.digicon.remessaBoleto.dao.BoletosEmitidosDAO;
import br.com.digicon.remessaBoleto.dao.SysParameterDAO;
import br.com.digicon.remessaBoleto.util.GeralUtility;
import br.com.digicon.remessaBoleto.vo.BoletosEmitidosVO;
import br.com.digicon.remessaBoleto.vo.ParamRemessaBoletoVO;
import br.com.digicon.remessaBoleto.vo.SysParameterVO;
import br.com.digicon.remessaBoleto.vo.ValoresDominioVO;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

public class RemessaBoletoSAFacade {
	
	private RemessaBoletoFacade remessaBoletoFacade;
	
	private SysParameterDAO sysParameterDAO;
	
	private BoletosEmitidosDAO boletosEmitidosDAO;
	
	private List<BoletosEmitidosVO> listaBoletosTotal;
	
	private List<BoletosEmitidosVO> listaBoletos;
	
	private List<BoletosEmitidosVO> listaBoletoCed1;
	
	private List<BoletosEmitidosVO> listaBoletoCed2;
	
	private List<JBoletoBean> boletos;
	
	private List<JBoletoBean> boletosCedente1;
	
	private List<JBoletoBean> boletosCedente2;
	
	private List<Date> listaFeriados;
	
	private Long NSA;
	
	private ParamRemessaBoletoVO param;
	
	private static final transient Logger LOG = Logger.getLogger(RemessaBoletoSAFacade.class);
	

	public void gerarRemessa() {
		//Obtem os dados que ser�o usados na remessa, logs de processamento e controle do que j� foi ou n�o emitido
		this.param = new ParamRemessaBoletoVO();
		this.param.setDataInicioProcesso(new Date());
		
//Destravar Objeto Para Garantir �nica Execu��o de Gera��o de Arquivo 
//this.sysParameterDAO.travarObjetoRemessaSA("FALSE");
		
		//Obtem os dados tabela SYSPARAMETER
		List<SysParameterVO> listaParametros = (List<SysParameterVO>) sysParameterDAO.findAllParametersByPrefixLista(); 
		//4.1 Header do Arquivo	
		for(int i=0;i<listaParametros.size();i++){
			if(listaParametros.get(i).getParameterName().equals("BOLETO_LOCK_REMESSA_SA")){
				this.param.setLockObjeto(BooleanUtils.toBooleanObject(listaParametros.get(i).getParameterValue()));
			}				
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_CODIGO_BANCO")){
				this.param.setCodBancoCompensacao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_CPF_CNPJ_SPTRANS")){
				this.param.setNumeroInscricaoEmpresa(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}	
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_NOME_CEDENTE")){
				this.param.setNomeCedente(listaParametros.get(i).getParameterValue());
				this.param.setNomeEmpresa(listaParametros.get(i).getParameterValue());
			}	
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_NOME_BANCO_CEDENTE")){
				this.param.setNomeBanco(listaParametros.get(i).getParameterValue());
			}	
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_VALOR_IOF")){
				this.param.setValorIof(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_QTD_DIAS_DEVOLUCAO")){
				this.param.setQtdeDiasDevolucao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}	
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_QTD_MAX_DIAS_VENCIMENTO")){
				this.param.setQtdeMaxDiasVenc(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}				
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_QTD_MAX_POR_LOTE")){
				this.param.setQtdeLotesArquivo(GeralUtility.calcularQtdeMaxLotes(Long.parseLong(listaParametros.get(i).getParameterValue())));
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_DTINICIO_REGISTRO")){
				this.param.setDataConsultaBoleto(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("DIRETORIO_GRAVACAO_REMESSA_SA")){
				this.param.setCaminhoGravacaoArquivo(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_ESTADO")){
				this.param.setUfSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_CIDADE")){
				this.param.setCidadeSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_ENDERECO")){
				this.param.setEnderecoSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_BAIRRO")){
				this.param.setBairroSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_CEP")){
				this.param.setCepSacadoPadrao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_SUFIXOCEP")){
				this.param.setSufixoCepSacadoPadrao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}		
			
			if(listaParametros.get(i).getParameterName().equals("CODIGO_CEDENTE_SCA_A")){
				this.param.setCodigoCedenteScaA(listaParametros.get(i).getParameterValue());
			}		
			
			if(listaParametros.get(i).getParameterName().equals("CODIGO_CEDENTE_SCA_B")){
				this.param.setCodigoCedenteScaB(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("QTDE_MAX_REG_ARQUIVO_REMESSA_SA")){
				this.param.setQtdeMaxBoletosArquivo(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}				
			
		}
		
		Date hoje = GeralUtility.hoje();
		Boolean isFeriado = (this.sysParameterDAO.getFeriados(hoje).size() > 0);
		Boolean isSabadoDomingo = GeralUtility.isSabadoDomingo();
		
		String dateAtual = GeralUtility.convertDateToString(hoje, "dd/MM/yyyy");
		
		// Verifica o Lock da Remessa LV 
		if(!this.param.getLockObjeto()){
			
			try {
			
				//trava Objeto Para Garantir �nica Execu��o de Gera��o de Arquivo   
				this.sysParameterDAO.travarObjetoRemessaSA("TRUE");
				
				this.boletos = new ArrayList<JBoletoBean>();
				this.boletosCedente1 = new ArrayList<JBoletoBean>();
				this.boletosCedente2 = new ArrayList<JBoletoBean>();
				this.listaBoletoCed1 = new ArrayList<BoletosEmitidosVO>();
				this.listaBoletoCed2 = new ArrayList<BoletosEmitidosVO>();
				this.listaFeriados   = new ArrayList<Date>();
			
			    String dateGeracaoArquivo = GeralUtility.convertDateToString(hoje, "ddMMyyyy");
			    this.listaFeriados = this.sysParameterDAO.getListaFeriados();
			    Date proxDiaUtil = GeralUtility.proxDiaUtil(this.listaFeriados);
/*		        Date dataParametro = GeralUtility.converteStringtoDate(this.param.getDataConsultaBoleto(), "dd/MM/yyyy");
			    
			    if(proxDiaUtil.before(dataParametro)){
			    	this.listaBoletos = boletosEmitidosDAO.listaBoletosSA(dataParametro);	
			    }else{*/
			    this.listaBoletos =  new ArrayList<BoletosEmitidosVO>();
			    	
		    	this.listaBoletosTotal = boletosEmitidosDAO.listaBoletosSA(proxDiaUtil); 
		    	
		    	int qtde = this.listaBoletosTotal.size();
			   	int j = 1;
			   	for(int i=0; i<this.param.getQtdeMaxBoletosArquivo(); i++){
			   		if(qtde >= j){    
			   			this.listaBoletos.add(this.listaBoletosTotal.get(i));
			   			j++;
			   		}else{
			   			break;
			   		}
			   	}
		    	
/*			    }*/
				
// REMOVER AO ENTREGAR!!!!! (05/06/2004)
// this.listaBoletos = boletosEmitidosDAO.listaBoletosSA(GeralUtility.converteStringtoDate("30/11/2015", "dd/MM/yyyy"));
			    
			    if(this.listaBoletos.size()>0){
					for(int i=0;i<this.listaBoletos.size();i++){
				
						XStream xstream = new XStream(new DomDriver());
						JBoletoBean jBoletoBean = (JBoletoBean) xstream.fromXML(this.listaBoletos.get(i).getBoleto());
						
						//sptrans.tb_boletos_emitidos.boleto.agencia
						if(jBoletoBean.getAgencia() != null){
							this.param.setAgencia(Long.parseLong(jBoletoBean.getAgencia()));
						}		
					
						//sptrans.tb_boletos_emitidos.boleto.instrucao1
						if(jBoletoBean.getInstrucao1() != null){
							this.param.setMensagem1(jBoletoBean.getInstrucao1());
						}	
					
						//sptrans.tb_boletos_emitidos.boleto.instrucao2
						if(jBoletoBean.getInstrucao2() != null){
							this.param.setMensagem2(jBoletoBean.getInstrucao2());
						}
						
						this.boletos.add(jBoletoBean);
					}
	
					//Digito Verificador da Conta
					this.param.setDvAgencia(GeralUtility.getMod11(Long.toString(this.param.getAgencia()), 9, 1));
				
					Long codigoCedente1 = 0L;
					Long codigoCedente2 = 0L;
					//separar codigo de cedente
					for(int i=0;i<this.boletos.size();i++){
				
						XStream xstream = new XStream(new DomDriver());
						JBoletoBean jBoletoBean = (JBoletoBean) xstream.fromXML(this.listaBoletos.get(i).getBoleto());
	
						//para lista com apenas 1 registro
						if(boletos.size() == 1){
							codigoCedente1 = Long.parseLong(jBoletoBean.getCodigoFornecidoAgencia());
							this.boletosCedente1.add(jBoletoBean);
							this.listaBoletoCed1.add(this.listaBoletos.get(i));
							
						}else if((i+1 < boletos.size()) & (boletos.size() > 1)){
							
							if(this.param.getCodigoCedenteScaA().equalsIgnoreCase(jBoletoBean.getCodigoFornecidoAgencia())){
								codigoCedente1 = Long.parseLong(jBoletoBean.getCodigoFornecidoAgencia());
								this.boletosCedente1.add(jBoletoBean);
								this.listaBoletoCed1.add(this.listaBoletos.get(i));
							}
							
							if(this.param.getCodigoCedenteScaB().equalsIgnoreCase(jBoletoBean.getCodigoFornecidoAgencia())){
								codigoCedente2 = Long.parseLong(jBoletoBean.getCodigoFornecidoAgencia());
								this.boletosCedente2.add(jBoletoBean);
								this.listaBoletoCed2.add(this.listaBoletos.get(i));
							}
						}
				
						//para ultimo registro da lista 
						if((i==(boletos.size()-1)) & (boletos.size() > 1)){
							
							if(this.param.getCodigoCedenteScaA().equalsIgnoreCase(jBoletoBean.getCodigoFornecidoAgencia())){
								codigoCedente1 = Long.parseLong(jBoletoBean.getCodigoFornecidoAgencia());
								this.boletosCedente1.add(jBoletoBean);
								this.listaBoletoCed1.add(this.listaBoletos.get(i));
							}
							
							if(this.param.getCodigoCedenteScaB().equalsIgnoreCase(jBoletoBean.getCodigoFornecidoAgencia())){
								codigoCedente2 = Long.parseLong(jBoletoBean.getCodigoFornecidoAgencia());
								this.boletosCedente2.add(jBoletoBean);
								this.listaBoletoCed2.add(this.listaBoletos.get(i));
							}
						} 
					}
					
					//Data Gera��o formato: DD/MM/YYYY
					this.param.setDataGeracao(dateAtual);
					//Data Gera��o formato: DDMMYYYY
					this.param.setDataGeracaoArquivo(dateGeracaoArquivo);
		
					Date hora = new Date();
					String strHoraGeracao = ""; 
					strHoraGeracao = GeralUtility.getHoraMinutoSegundo(hora);
		    
					//Hora Gera��o formato: HHMMSS
					this.param.setHoraGeracao(strHoraGeracao);
					this.param.setDataGravacao(dateAtual);
					//Solicita a gera��o do arquivo de remessa 
					if((this.boletosCedente1.size()>0) & (!isFeriado) & (!isSabadoDomingo)){
						
						this.param.setCodigoCedente(codigoCedente1);
						this.param.setQtdeRegistrosLote(2L + (this.boletosCedente1.size() * 2));
						this.param.setQtdeRegistrosArquivo(4L + (this.boletosCedente1.size() * 2));
					
						Integer tamanhoLista = this.boletosCedente1.size();
						this.param.setQtdeBoletosArquivo(Long.parseLong(tamanhoLista.toString()));
						
						//C�digo NSA (Numero Remessa)
						this.NSA = boletosEmitidosDAO.obterNumeroNSA();
						this.param.setNumeroRemessa(NSA);
						
						this.atualizarStatusGeracaoInicio("StatusProcRemessaBoleto", "Iniciado");
						
						this.remessaBoletoFacade.remessa(this.param, NSA, this.boletosCedente1, this.listaBoletoCed1, "SCA");
						
						// Atualizar flags dos boletos
						this.atualizarBoletos(this.listaBoletoCed1, this.param.getArquivoId());
						
						// Atualizar status da gera��o
						this.atualizarStatusGeracaoFim("StatusProcRemessaBoleto", "Sucesso");	
					}
				
				    //Solicita a gera��o do arquivo de remessa
					if((this.boletosCedente2.size()>0) & (!isFeriado) & (!isSabadoDomingo)){
						
						this.param.setCodigoCedente(codigoCedente2);
						this.param.setQtdeRegistrosLote(2L + (this.boletosCedente2.size() * 2));
						this.param.setQtdeRegistrosArquivo(4L + (this.boletosCedente2.size() * 2));
						
						Integer tamanhoLista = this.boletosCedente2.size();
						this.param.setQtdeBoletosArquivo(Long.parseLong(tamanhoLista.toString()));
										
						//C�digo NSA (Numero Remessa)
					 	this.NSA = boletosEmitidosDAO.obterNumeroNSA();	
					 	this.param.setNumeroRemessa(NSA);
					 	
						// Atualizar status da gera��o	
						this.atualizarStatusGeracaoInicio("StatusProcRemessaBoleto", "Iniciado");
						
						this.remessaBoletoFacade.remessa(this.param, NSA, this.boletosCedente2, this.listaBoletoCed2, "SCA");
						
						// Atualizar flags dos boletos
						this.atualizarBoletos(this.listaBoletoCed2, this.param.getArquivoId());
						
						// Atualizar status da gera��o	
						this.atualizarStatusGeracaoFim("StatusProcRemessaBoleto", "Sucesso");
					}
					
			    }else{
			    	
			    	LOG.info("SEM DADOS DE BOLETOS PARA GERACAO DE REMESSA!");
			    }	
			    //Destravar Objeto Para Garantir �nica Execu��o de Gera��o de Arquivo 
				this.sysParameterDAO.travarObjetoRemessaSA("FALSE");
			
			} catch (Exception e) {
				LOG.info(e.getMessage());
				this.sysParameterDAO.travarObjetoRemessaSA("FALSE");
				this.atualizarStatusGeracaoFim("ErroProcRemessaBoleto", "Erro");
				LOG.error(e.getMessage());
				LOG.error("Erro ao Efetuar Remessa.");
				e.printStackTrace();
			}
			
		
		} else {
			// Gerar LOG
			LOG.info("Remessa Boleto SA COM LOCK PARA OUTRA EXECUCAO.");
		}
	}
	
	
	public void atualizarBoletos(List<BoletosEmitidosVO> listaBoleto, Long arquivoId){
		
		 for(int i=0; i<listaBoleto.size();i++ ){
			
			listaBoleto.get(i).setArquivoRemessaId(arquivoId); 
			this.boletosEmitidosDAO.atualizaFlagBoletoRemessaSA(listaBoleto.get(i));
		
		}
	}
	
	
	public void atualizarStatusGeracaoInicio(String domainName, String itemName){

		// Atualizar status da gera��o
		ValoresDominioVO dominio = new ValoresDominioVO();
		dominio.setDomainName(domainName);
		dominio.setItemName(itemName);
		dominio = this.sysParameterDAO.findByDominioItemRemessa(dominio);
		
		//sequence SPTRANS.SEQ_CTR_REMESSA_BOLETO
		this.param.setProcessoId(this.param.getNumeroRemessa());
		this.param.setDataFimProcesso(null);
		this.param.setDataInicioProcesso(new Date());
		this.param.setCodStatus(dominio.getCodeNumber());
		this.param.setCodigoErro(dominio.getCodeNumber());
		this.param.setMensagemErro(dominio.getDescription());
		
		//SPTRANS.TB_CTR_REMESSA_BOLETO
		this.sysParameterDAO.inserirContrRemessaSA(this.param);
		
        //sequence SPTRANS.SEQ_DETALHE_REMESSA_BOLETO    
		this.param.setArquivoId(this.boletosEmitidosDAO.obterProcessoDetalheIdSA());
		this.param.setDataInicioGeracao(new Date());
		this.param.setDataAlteracao(null);
		
		//SPTRANS.TB_DETALHE_REMESSA_BOLETO
		this.sysParameterDAO.inserirContrRemessaDetalhesSA(this.param);
	}
	
	
	public void atualizarStatusGeracaoFim(String domainName, String itemName){

		// Atualizar status da gera��o
		ValoresDominioVO dominio = new ValoresDominioVO();
		dominio.setDomainName(domainName);
		dominio.setItemName(itemName);
		dominio = this.sysParameterDAO.findByDominioItemRemessa(dominio);
		
		//sequence SPTRANS.SEQ_CTR_REMESSA_BOLETO
		this.param.setProcessoId(this.param.getNumeroRemessa());
		this.param.setDataInicioProcesso(this.param.getDataInicioProcesso());
	    this.param.setDataFimProcesso(new Date());
		this.param.setCodStatus(dominio.getCodeNumber());
		this.param.setCodigoErro(dominio.getCodeNumber());
		this.param.setMensagemErro(dominio.getDescription());
		
		//SPTRANS.TB_CTR_REMESSA_BOLETO
		this.sysParameterDAO.updateContrRemessaSA(this.param);
		
        //sequence SPTRANS.SEQ_DETALHE_REMESSA_BOLETO    
		//this.param.setArquivoId(this.boletosEmitidosDAO.obterProcessoDetalheId());
		this.param.setDataAlteracao(new Date());
		
		//SPTRANS.TB_DETALHE_REMESSA_BOLETO
		this.sysParameterDAO.updateContrRemessaDetalhesSA(this.param);
	}
	
	
	public SysParameterDAO getSysParameterDAO() {
		return sysParameterDAO;
	}

	public void setSysParameterDAO(SysParameterDAO sysParameterDAO) {
		this.sysParameterDAO = sysParameterDAO;
	}

	public BoletosEmitidosDAO getBoletosEmitidosDAO() {
		return boletosEmitidosDAO;
	}

	public void setBoletosEmitidosDAO(BoletosEmitidosDAO boletosEmitidosDAO) {
		this.boletosEmitidosDAO = boletosEmitidosDAO;
	}

	public RemessaBoletoFacade getRemessaBoletoFacade() {
		return remessaBoletoFacade;
	}

	public void setRemessaBoletoFacade(RemessaBoletoFacade remessaBoletoFacade) {
		this.remessaBoletoFacade = remessaBoletoFacade;
	}

	public List<JBoletoBean> getBoletosCedente1() {
		return boletosCedente1;
	}

	public void setBoletosCedente1(List<JBoletoBean> boletosCedente1) {
		this.boletosCedente1 = boletosCedente1;
	}

	public List<JBoletoBean> getBoletosCedente2() {
		return boletosCedente2;
	}

	public void setBoletosCedente2(List<JBoletoBean> boletosCedente2) {
		this.boletosCedente2 = boletosCedente2;
	}

	public List<JBoletoBean> getBoletos() {
		return boletos;
	}
	 
	public void setBoletos(List<JBoletoBean> boletos) {
		this.boletos = boletos;
	}

	public Long getNSA() {
		return NSA;
	}

	public void setNSA(Long nSA) {
		NSA = nSA;
	}

	public ParamRemessaBoletoVO getParam() {
		return param;
	}

	public void setParam(ParamRemessaBoletoVO param) {
		this.param = param;
	}

	public List<BoletosEmitidosVO> getListaBoletos() {
		return listaBoletos;
	}

	public void setListaBoletos(List<BoletosEmitidosVO> listaBoletos) {
		this.listaBoletos = listaBoletos;
	}
	
	public List<BoletosEmitidosVO> getListaBoletosTotal() {
		return listaBoletosTotal;
	}

	public void setListaBoletosTotal(List<BoletosEmitidosVO> listaBoletosTotal) {
		this.listaBoletosTotal = listaBoletosTotal;
	}

	public List<Date> getListaFeriados() {
		return listaFeriados;
	}

	public void setListaFeriados(List<Date> listaFeriados) {
		this.listaFeriados = listaFeriados;
	}
	
	
}
