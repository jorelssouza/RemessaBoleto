package br.com.digicon.remessaBoleto.facade;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang.BooleanUtils;
import org.jboleto.JBoletoBean;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import org.apache.log4j.Logger;
import br.com.digicon.remessaBoleto.dao.BoletosEmitidosDAO;
import br.com.digicon.remessaBoleto.dao.SysParameterDAO;
import br.com.digicon.remessaBoleto.util.GeralUtility;
import br.com.digicon.remessaBoleto.vo.BoletosEmitidosVO;
import br.com.digicon.remessaBoleto.vo.ParamRemessaBoletoVO;
import br.com.digicon.remessaBoleto.vo.SysParameterVO;
import br.com.digicon.remessaBoleto.vo.ValoresDominioVO;

public class RemessaBoletoVCWFacade {
	
	private RemessaBoletoFacade remessaBoletoFacade;
	
	private BoletosEmitidosDAO boletosEmitidosDAO;
	
	private List<BoletosEmitidosVO> listaBoletos;
	
	private List<BoletosEmitidosVO> listaBoletosTotal;
	
	private List<BoletosEmitidosVO> listaBoletoCed1;
	
	private List<BoletosEmitidosVO> listaBoletoCed2;
	
	private List<Date> listaFeriados;
	
	private List<JBoletoBean> boletos;
	
	private List<JBoletoBean> boletosCedente1;
	
	private List<JBoletoBean> boletosCedente2;
	
	private Long NSA;
	
	private ParamRemessaBoletoVO param;
	
	private SysParameterDAO sysParameterDAO;
	
	private static final transient Logger LOG = Logger.getLogger(RemessaBoletoVCWFacade.class);
	
	
	public void updateTravaObjetoRemessa(String estado){
		//trava Objeto Para Garantir �nica Execu��o de Gera��o de Arquivo   
		this.sysParameterDAO.updateObjetoRemessaVCW(estado);
	}	
	
	public void gerarRemessa() {
		
		LOG.info("Iniciando Remessa VCW...");	
		
		//Obtem os dados que ser�o usados na remessa, logs de processamento e controle do que j� foi ou n�o emitido
		this.param = new ParamRemessaBoletoVO();
		this.param.setDataInicioProcesso(new Date());
		
		//Destravar Objeto Para Garantir �nica Execu��o de Gera��o de Arquivo 
		//this.updateTravaObjetoRemessa("FALSE");	
		
		//Obtem os dados tabela SYSPARAMETER
		List<SysParameterVO> listaParametros = (List<SysParameterVO>) sysParameterDAO.findAllParametersByPrefixLista(); 
				
		//4.1 Header do Arquivo	
		for(int i=0;i<listaParametros.size();i++){
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_LOCK_REMESSA_VCW")){
				this.param.setLockObjeto(BooleanUtils.toBooleanObject(listaParametros.get(i).getParameterValue()));
			}	
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_CODIGO_BANCO")){
				this.param.setCodBancoCompensacao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_CPF_CNPJ_SPTRANS")){
				this.param.setNumeroInscricaoEmpresa(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}	
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_NOME_CEDENTE")){
				this.param.setNomeCedente(listaParametros.get(i).getParameterValue());
				this.param.setNomeEmpresa(listaParametros.get(i).getParameterValue());
			}				
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_NOME_BANCO_CEDENTE")){
				this.param.setNomeBanco(listaParametros.get(i).getParameterValue());
			}	
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_VALOR_IOF")){
				this.param.setValorIof(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_QTD_DIAS_DEVOLUCAO")){
				this.param.setQtdeDiasDevolucao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}	
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_QTD_MAX_DIAS_VENCIMENTO")){
				this.param.setQtdeMaxDiasVenc(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_QTD_MAX_POR_LOTE")){
				this.param.setQtdeLotesArquivo(GeralUtility.calcularQtdeMaxLotes(Long.parseLong(listaParametros.get(i).getParameterValue())));
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_DTINICIO_REGISTRO")){
				this.param.setDataConsultaBoleto(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("DIRETORIO_GRAVACAO_REMESSA_COMUM_VCW")){
				this.param.setCaminhoGravacaoArquivoVcwComum(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("DIRETORIO_GRAVACAO_REMESSA_ESTUDANTE_VCW")){
				this.param.setCaminhoGravacaoArquivoVcwEst(listaParametros.get(i).getParameterValue());
			}			
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_ESTADO")){
				this.param.setUfSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_CIDADE")){
				this.param.setCidadeSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_ENDERECO")){
				this.param.setEnderecoSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_BAIRRO")){
				this.param.setBairroSacadoPadrao(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_CEP")){
				this.param.setCepSacadoPadrao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}
			
			if(listaParametros.get(i).getParameterName().equals("BOLETO_PADRAO_SUFIXOCEP")){
				this.param.setSufixoCepSacadoPadrao(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}						
			
			if(listaParametros.get(i).getParameterName().equals("CODIGO_CEDENTE_VCW_COMUM")){
				this.param.setCodigoCedenteVcwComum(listaParametros.get(i).getParameterValue());
			}						
			
			if(listaParametros.get(i).getParameterName().equals("CODIGO_CEDENTE_VCW_ESTUDANTE")){
				this.param.setCodigoCedenteVcwEstudante(listaParametros.get(i).getParameterValue());
			}
			
			if(listaParametros.get(i).getParameterName().equals("QTDE_MAX_REG_ARQUIVO_REMESSA_VCW")){
				this.param.setQtdeMaxBoletosArquivo(Long.parseLong(listaParametros.get(i).getParameterValue()));
			}						
			
		}
		
		// Verifica o Lock da Remessa VCW
		if(this.param.getLockObjeto()){
			
			try {
		
			    this.boletos = new ArrayList<JBoletoBean>();
				this.boletosCedente1 = new ArrayList<JBoletoBean>();
				this.boletosCedente2 = new ArrayList<JBoletoBean>();
				this.listaBoletoCed1 = new ArrayList<BoletosEmitidosVO>();
				this.listaBoletoCed2 = new ArrayList<BoletosEmitidosVO>();
				this.listaFeriados   = new ArrayList<Date>();
				
				Date hoje = GeralUtility.hoje();
			    String dateAtual = GeralUtility.convertDateToString(hoje, "dd/MM/yyyy");
			    String dateGeracaoArquivo = GeralUtility.convertDateToString(hoje, "ddMMyyyy");
			    Boolean isFeriado = (this.sysParameterDAO.getFeriados(hoje).size() > 0);
				Boolean isSabadoDomingo = GeralUtility.isSabadoDomingo();
				
			    this.listaFeriados = this.sysParameterDAO.getListaFeriados();
				//Date proxDiaUtil = GeralUtility.proxDiaUtil(this.listaFeriados);
				//Date dataParametro = GeralUtility.converteStringtoDate(this.param.getDataConsultaBoleto(), "dd/MM/yyyy");
				//if(proxDiaUtil.before(dataParametro)){
				//this.listaBoletos = boletosEmitidosDAO.listaBoletosVCW(dataParametro);	
				//}else{
			    
			    LOG.info("Consultando Boletos VCW...");

			    this.listaBoletos =  new ArrayList<BoletosEmitidosVO>();
			    
			    //this.listaBoletos = boletosEmitidosDAO.listaBoletosVCW(hoje);
			    
			    this.listaBoletosTotal = boletosEmitidosDAO.listaBoletosVCW(hoje);
			   	
			 	int qtde = this.listaBoletosTotal.size();
			   	int j = 1;
			   	for(int i=0; i<this.param.getQtdeMaxBoletosArquivo(); i++){
			   		if(qtde >= j){    
			   			this.listaBoletos.add(this.listaBoletosTotal.get(i));
			   			j++;
			   		}else{
			   			break;
			   		}
			   	}
			   	
			   	LOG.info("Fim da Consulta Boletos VCW...");
//}
// REMOVER AO ENTREGAR!!!!! (05/06/2004)
//this.listaBoletos = boletosEmitidosDAO.listaBoletosVCW(GeralUtility.converteStringtoDate("30/11/2015", "dd/MM/yyyy"));
			    
				LOG.info("Qtde de Boletos VCW..." + this.listaBoletos.size());
			   	
			    if(this.listaBoletos.size()>0){
			    	
			    	LOG.info("Obtendo msg Boletos VCW...");
			    
					for(int i=0;i<this.listaBoletos.size();i++){
				
						XStream xstream = new XStream(new DomDriver());
						JBoletoBean jBoletoBean = (JBoletoBean) xstream.fromXML(this.listaBoletos.get(i).getBoleto());
LOG.info("Obtendo agencia JboletoBean...");
						//spservice.tb_cob_boleto.boleto.agencia
						if(jBoletoBean.getAgencia() != null){
							this.param.setAgencia(Long.parseLong(jBoletoBean.getAgencia()));
						}		
LOG.info("Obtendo instrucao JboletoBean...");				
						//spservice.tb_cob_boleto.boleto.instrucao1
						if(jBoletoBean.getInstrucao1() != null){
							this.param.setMensagem1(jBoletoBean.getInstrucao1());
						}	
LOG.info("Obtendo instrucao2 JboletoBean...");				
						//spservice.tb_cob_boleto.boleto.instrucao2
						if(jBoletoBean.getInstrucao2() != null){
							this.param.setMensagem2(jBoletoBean.getInstrucao2());
						}
				
						this.boletos.add(jBoletoBean);
					}	
		
					this.param.setDvAgencia(GeralUtility.getMod11(Long.toString(param.getAgencia()), 9, 1));
					
					Long codigoCedente1 = 0L;
					Long codigoCedente2 = 0L;
					
LOG.info("tamanho de boletos..."+ this.boletos.size());

					//separar codigo de cedente
					for(int i=0;i<this.boletos.size();i++){
				
						XStream xstream = new XStream(new DomDriver());
						JBoletoBean jBoletoBean = (JBoletoBean) xstream.fromXML(this.listaBoletos.get(i).getBoleto());
	
						//para lista com apenas 1 registro
						if(boletos.size() == 1){
							codigoCedente1 = Long.parseLong(jBoletoBean.getCodigoFornecidoAgencia());
							this.boletosCedente1.add(jBoletoBean);
							this.listaBoletoCed1.add(this.listaBoletos.get(i));
							
						}else if((i+1 < boletos.size()) & (boletos.size() > 1)){
							
							if(this.param.getCodigoCedenteVcwComum().equalsIgnoreCase(jBoletoBean.getCodigoFornecidoAgencia())){
								codigoCedente1 = Long.parseLong(jBoletoBean.getCodigoFornecidoAgencia());
								this.boletosCedente1.add(jBoletoBean);
								this.listaBoletoCed1.add(this.listaBoletos.get(i));
			LOG.info("cedente 1...");
							}
							
							if(this.param.getCodigoCedenteVcwEstudante().equalsIgnoreCase(jBoletoBean.getCodigoFornecidoAgencia())){
								codigoCedente2 = Long.parseLong(jBoletoBean.getCodigoFornecidoAgencia());
								this.boletosCedente2.add(jBoletoBean);
								this.listaBoletoCed2.add(this.listaBoletos.get(i));
								
			LOG.info("cedente 2...");								
							}
						}
				
						//para ultimo registro da lista 
						if((i==(boletos.size()-1)) & (boletos.size() > 1)){
							
							if(this.param.getCodigoCedenteVcwComum().equalsIgnoreCase(jBoletoBean.getCodigoFornecidoAgencia())){
								codigoCedente1 = Long.parseLong(jBoletoBean.getCodigoFornecidoAgencia());
								this.boletosCedente1.add(jBoletoBean);
								this.listaBoletoCed1.add(this.listaBoletos.get(i));
			LOG.info("cedente comum...ultimo");			
							}
							
							if(this.param.getCodigoCedenteVcwEstudante().equalsIgnoreCase(jBoletoBean.getCodigoFornecidoAgencia())){
								codigoCedente2 = Long.parseLong(jBoletoBean.getCodigoFornecidoAgencia());
								this.boletosCedente2.add(jBoletoBean);
								this.listaBoletoCed2.add(this.listaBoletos.get(i));
			LOG.info("cedente estudante...ultimo");								
							}
						} 
					}					
				    
				    // Data Gera��o formato: DD/MM/YYYY
				    this.param.setDataGeracao(dateAtual);
				    // Data Gera��o formato: DDMMYYYY
				    this.param.setDataGeracaoArquivo(dateGeracaoArquivo);
					
				    Date hora = new Date();
				    String strHoraGeracao = ""; 
				    strHoraGeracao = GeralUtility.getHoraMinutoSegundo(hora);
			    
				    // Hora Gera��o formato: HHMMSS
				    this.param.setHoraGeracao(strHoraGeracao);		
				    this.param.setDataGravacao(dateAtual);		
				
				    //Solicita a gera��o do arquivo de remessa
					if((this.boletosCedente1.size()>0) & (!isFeriado) & (!isSabadoDomingo)){
						
						this.param.setCodigoCedente(codigoCedente1);
						this.param.setQtdeRegistrosLote(2L + (this.boletosCedente1.size() * 2));
						this.param.setQtdeRegistrosArquivo(4L + (this.boletosCedente1.size() * 2)); 
						
						//C�digo NSA (Numero Remessa)
					 	this.NSA = boletosEmitidosDAO.obterNumeroNSAVCW();
					 	this.param.setNumeroRemessa(NSA);
					 	
					 	Integer tamanhoLista = this.boletosCedente1.size();
						this.param.setQtdeBoletosArquivo(Long.parseLong(tamanhoLista.toString()));
					
						this.updateStatusGeracaoInicio("StatusProcRemessaBoleto", "Iniciado");
						
						try{
						
							this.remessaBoletoFacade.remessa(param, NSA, this.boletosCedente1, this.listaBoletoCed1, "VCW");

							// Atualizar status da gera��o	
							this.updateStatusGeracaoFim("StatusProcRemessaBoleto", "Sucesso");						
						
							// Atualizar flags dos boletos
							this.updateBoletos(this.listaBoletoCed1, this.param.getArquivoId());
						
						} catch (Exception e) {
							
							LOG.info(e.getMessage());
							this.updateTravaObjetoRemessa("FALSE");
							this.updateStatusGeracaoFim("ErroProcRemessaBoleto", "Erro");
							LOG.error(e.getMessage());
							LOG.error("Erro ao Efetuar Remessa.");	
							LOG.error(e.getStackTrace());
							e.printStackTrace();
						}		
							
					}	
			
					
					//Solicita a gera��o do arquivo de remessa
					if((this.boletosCedente2.size()>0) & (!isFeriado) & (!isSabadoDomingo)){
						
						this.param.setCodigoCedente(codigoCedente2);
						this.param.setQtdeRegistrosLote(2L + (this.boletosCedente2.size() * 2));
						this.param.setQtdeRegistrosArquivo(4L + (this.boletosCedente2.size() * 2)); 
			
						Integer tamanhoLista = this.boletosCedente2.size();
						this.param.setQtdeBoletosArquivo(Long.parseLong(tamanhoLista.toString()));
						
						//C�digo NSA (Numero Remessa)
					 	this.NSA = boletosEmitidosDAO.obterNumeroNSAVCW();	
					 	this.param.setNumeroRemessa(NSA);
					 	
					 	this.updateStatusGeracaoInicio("StatusProcRemessaBoleto", "Iniciado");
					 	
					 	try{
					 		
							this.remessaBoletoFacade.remessa(param, NSA, this.boletosCedente2, this.listaBoletoCed2, "VCW");

							// Atualizar status da gera��o	
							this.updateStatusGeracaoFim("StatusProcRemessaBoleto", "Sucesso");
							
							// Atualizar flags dos boletos
							this.updateBoletos(this.listaBoletoCed2, this.param.getArquivoId());

					 	} catch (Exception e) {
					 		
							LOG.info(e.getMessage());
							this.updateTravaObjetoRemessa("FALSE");
							this.updateStatusGeracaoFim("ErroProcRemessaBoleto", "Erro");
							LOG.error(e.getMessage());
							LOG.error("Erro ao Efetuar Remessa.");	
							LOG.error(e.getStackTrace());
							e.printStackTrace();
						}		
					}
			    }else{
			    	
			    	LOG.info("SEM DADOS DE BOLETOS PARA GERACAO DE REMESSA!");			    	
			    }	

				//Destravar Objeto Para Garantir �nica Execu��o de Gera��o de Arquivo 
				this.updateTravaObjetoRemessa("FALSE");				
			
			} catch (Exception e) {
				
				LOG.info(e.getMessage());
				this.updateTravaObjetoRemessa("FALSE");
				LOG.error(e.getMessage());
				LOG.error("Erro ao Efetuar Remessa.");
				LOG.error(e.getStackTrace());
				e.printStackTrace();
			}
		
		} else {

			// Gerar LOG
			LOG.info("Remessa Boleto VCW COM LOCK PARA OUTRA EXECUCAO.");
		}
	}
	
	public void updateBoletos(List<BoletosEmitidosVO> boletos, Long arquivoId){
		
		for(int i=0; i< boletos.size();i++ ){
			boletos.get(i).setArquivoRemessaId(arquivoId);
			this.boletosEmitidosDAO.updateFlagBoletoRemessaVCW(boletos.get(i));
			
		}
	}
	
	public void updateStatusGeracaoInicio(String domainName, String itemName){
		
		//Atualizar status da gera��o
		ValoresDominioVO dominio = new ValoresDominioVO();
		dominio.setDomainName(domainName);
		dominio.setItemName(itemName);
		dominio = this.sysParameterDAO.findByDominioItemRemessa(dominio);
				
		//sequence SPSERVICE.SEQ_CTR_REMESSA_BOLETO
		this.param.setProcessoId(this.param.getNumeroRemessa());
	    this.param.setDataFimProcesso(null);
	    this.param.setDataInicioProcesso(new Date());
		this.param.setCodStatus(dominio.getCodeNumber());
		this.param.setCodigoErro(dominio.getCodeNumber());
		this.param.setMensagemErro(dominio.getDescription());
				
		//SPSERVICE.TB_CTR_REMESSA_BOLETO
		this.sysParameterDAO.inserirContrRemessaVCW(this.param);
		
        //sequence SPSERVICE.SEQ_DETALHE_REMESSA_BOLETO    
		this.param.setArquivoId(this.boletosEmitidosDAO.obterProcessoDetalheIdVCW());
		this.param.setDataInicioGeracao(new Date());
		this.param.setDataAlteracao(null);
		
		//SPSERVICE.TB_DETALHE_REMESSA_BOLETO
		this.sysParameterDAO.inserirContrRemessaDetalhesVCW(this.param);
	}
	
	public void updateStatusGeracaoFim(String domainName, String itemName){
		
		//Atualizar status da gera��o
		ValoresDominioVO dominio = new ValoresDominioVO();
		dominio.setDomainName(domainName);
		dominio.setItemName(itemName);
		dominio = this.sysParameterDAO.findByDominioItemRemessa(dominio);
				
		//sequence SPSERVICE.SEQ_CTR_REMESSA_BOLETO
		this.param.setProcessoId(this.param.getNumeroRemessa());
		this.param.setDataInicioProcesso(this.param.getDataInicioProcesso());
	    this.param.setDataFimProcesso(new Date());
		this.param.setCodStatus(dominio.getCodeNumber());
		this.param.setCodigoErro(dominio.getCodeNumber());
		this.param.setMensagemErro(dominio.getDescription());
				
		//SPSERVICE.TB_CTR_REMESSA_BOLETO
		
		//dar update
		this.sysParameterDAO.updateContrRemessaVCW(this.param);
		
        //sequence SPSERVICE.SEQ_DETALHE_REMESSA_BOLETO    
		//this.param.setArquivoId(this.boletosEmitidosDAO.obterProcessoDetalheId());
		this.param.setDataAlteracao(new Date());
		
		//SPSERVICE.TB_DETALHE_REMESSA_BOLETO
		this.sysParameterDAO.updateTabControleRemessaDetalhesVCW(this.param);
	}
	
	
	
	public SysParameterDAO getSysParameterDAO() {
		return sysParameterDAO;
	}

	public void setSysParameterDAO(SysParameterDAO sysParameterDAO) {
		this.sysParameterDAO = sysParameterDAO;
	}

	public RemessaBoletoFacade getRemessaBoletoFacade() {
		return remessaBoletoFacade;
	}


	public void setRemessaBoletoFacade(RemessaBoletoFacade remessaBoletoFacade) {
		this.remessaBoletoFacade = remessaBoletoFacade;
	}

	public BoletosEmitidosDAO getBoletosEmitidosDAO() {
		return boletosEmitidosDAO;
	}

	public void setBoletosEmitidosDAO(BoletosEmitidosDAO boletosEmitidosDAO) {
		this.boletosEmitidosDAO = boletosEmitidosDAO;
	}

	public List<JBoletoBean> getBoletos() {
		return boletos;
	}

	public void setBoletos(List<JBoletoBean> boletos) {
		this.boletos = boletos;
	}

	public List<JBoletoBean> getBoletosCedente1() {
		return boletosCedente1;
	}

	public void setBoletosCedente1(List<JBoletoBean> boletosCedente1) {
		this.boletosCedente1 = boletosCedente1;
	}


	public List<JBoletoBean> getBoletosCedente2() {
		return boletosCedente2;
	}

	public void setBoletosCedente2(List<JBoletoBean> boletosCedente2) {
		this.boletosCedente2 = boletosCedente2;
	}

	public Long getNSA() {
		return NSA;
	}
	
	public void setNSA(Long nSA) {
		NSA = nSA;
	}

	public List<BoletosEmitidosVO> getListaBoletos() {
		return listaBoletos;
	}
	
	public void setListaBoletos(List<BoletosEmitidosVO> listaBoletos) {
		this.listaBoletos = listaBoletos;
	}

	public List<BoletosEmitidosVO> getListaBoletosTotal() {
		return listaBoletosTotal;
	}

	public void setListaBoletosTotal(List<BoletosEmitidosVO> listaBoletosTotal) {
		this.listaBoletosTotal = listaBoletosTotal;
	}

	public List<BoletosEmitidosVO> getListaBoletoCed1() {
		return listaBoletoCed1;
	}

	public void setListaBoletoCed1(List<BoletosEmitidosVO> listaBoletoCed1) {
		this.listaBoletoCed1 = listaBoletoCed1;
	}

	public List<BoletosEmitidosVO> getListaBoletoCed2() {
		return listaBoletoCed2;
	}

	public void setListaBoletoCed2(List<BoletosEmitidosVO> listaBoletoCed2) {
		this.listaBoletoCed2 = listaBoletoCed2;
	}
	
	public List<Date> getListaFeriados() {
		return listaFeriados;
	}
	
	public void setListaFeriados(List<Date> listaFeriados) {
		this.listaFeriados = listaFeriados;
	}
	
	
}