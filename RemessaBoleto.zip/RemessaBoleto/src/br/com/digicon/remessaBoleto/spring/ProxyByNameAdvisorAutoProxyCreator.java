package br.com.digicon.remessaBoleto.spring;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.aop.TargetSource;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;

public class ProxyByNameAdvisorAutoProxyCreator extends DefaultAdvisorAutoProxyCreator {

    private static final long serialVersionUID = 1L;

    private String beanNamesRegex;

    private Pattern pattern;

    public ProxyByNameAdvisorAutoProxyCreator() {

    }

    @SuppressWarnings("unchecked")
    @Override
    protected Object[] getAdvicesAndAdvisorsForBean(Class beanClass, String name, TargetSource targetSource) {
        Matcher matcher = pattern.matcher(name);
        if (matcher.matches()) {
            return super.getAdvicesAndAdvisorsForBean(beanClass, name, targetSource);
        }
        return DO_NOT_PROXY;
    }

    public String getBeanNamesRegex() {
        return beanNamesRegex;
    }

    public void setBeanNamesRegex(String beanNamesRegex) {
        this.beanNamesRegex = beanNamesRegex;
        pattern = Pattern.compile(beanNamesRegex);
    }

}