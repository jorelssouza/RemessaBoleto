package br.com.digicon.remessaBoleto.spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SingletonBeanFactory {

	private static ApplicationContext applicationContext ;
    
    private SingletonBeanFactory() {
    }
    public static BeanFactory getBeanFactory() {
        if (applicationContext == null) {
            applicationContext = new ClassPathXmlApplicationContext(new String[] {"applicationContext.xml"});
        }
 
        return applicationContext;
    }

}
