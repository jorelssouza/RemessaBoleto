package br.com.digicon.remessaBoleto.spring;

import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;

import br.com.digicon.remessaBoleto.util.Criptografia;
import br.com.digicon.remessaBoleto.util.SingletonPropertiesIni;


public class ChoiceBeanByNameJNDI implements InitializingBean, FactoryBean, BeanFactoryAware {

    private static final transient Logger LOG = Logger.getLogger(ChoiceBeanByNameJNDI.class);

    private String prefix;
    private String jndiName;
    private BeanFactory beanFactory;
    private String defaultChoice;
    private BasicDataSource bean;

    public String getDefaultChoice() {
        return this.defaultChoice;
    }

    public void setDefaultChoice(String defaultChoice) {
        this.defaultChoice = defaultChoice;
    }

    public ChoiceBeanByNameJNDI() {

    }

    public String getJndiName() {
        return this.jndiName;
    }

    public void setJndiName(String jndiName) {
        this.jndiName = jndiName;
    }

    public String getPrefix() {
        return this.prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }

    public Object getObject() throws Exception {
        return bean;
    }

    @SuppressWarnings("unchecked")
    public Class getObjectType() {
        return bean == null ? null : bean.getClass();
    }

    public boolean isSingleton() {
        return false;
    }

    public void afterPropertiesSet() throws Exception {
        String ambiente = null;
        String beanName = null;
        try {
        	
        	Properties prop = SingletonPropertiesIni.getProperties();
        	ambiente = prop.getProperty("ambiente");
            beanName = prefix + ambiente;
            
            if (beanFactory.containsBean(beanName)){
                bean = (BasicDataSource) beanFactory.getBean(beanName);
                
                bean.setUsername(Criptografia.decripta(bean.getUsername()));
                bean.setPassword(Criptografia.decripta(bean.getPassword()));
                
//                bean.setUsername(bean.getUsername());
//                bean.setPassword(bean.getPassword());
                
            }

        } catch (Exception e) {
            LOG.warn("Falha ao tentar obter o nome JNDI " + jndiName);
            System.out.println("Falha ao tentar obter o nome JNDI " + jndiName);
            beanName = prefix + defaultChoice;
            if (beanFactory.containsBean(beanName)){
                bean = (BasicDataSource) beanFactory.getBean(beanName);
                bean.setUsername(Criptografia.decripta(bean.getUsername()));
                bean.setPassword(Criptografia.decripta(bean.getPassword()));
            }
        }
    }

}
