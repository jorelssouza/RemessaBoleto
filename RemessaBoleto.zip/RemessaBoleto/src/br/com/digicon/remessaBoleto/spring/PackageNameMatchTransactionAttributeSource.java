package br.com.digicon.remessaBoleto.spring;


import java.lang.reflect.Method;

import org.springframework.transaction.interceptor.NameMatchTransactionAttributeSource;
import org.springframework.transaction.interceptor.TransactionAttribute;

public class PackageNameMatchTransactionAttributeSource extends NameMatchTransactionAttributeSource {

	private static final long serialVersionUID = 1L;

	private String packageName;

	public String getPackageName() {
		return packageName;
	}

	@SuppressWarnings("unchecked")
    public TransactionAttribute getTransactionAttribute(Method method, Class targetClass) {
		if (!targetClass.getName().startsWith(packageName))
			return null;
		return super.getTransactionAttribute(method, targetClass);
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public PackageNameMatchTransactionAttributeSource() {
		super();
	}

}
