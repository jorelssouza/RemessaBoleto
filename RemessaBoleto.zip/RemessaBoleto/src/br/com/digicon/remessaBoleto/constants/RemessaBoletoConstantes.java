package br.com.digicon.remessaBoleto.constants;

public final class RemessaBoletoConstantes {
	

	// Tipo de Registro do Arquivo de Remessa de T�tulo
	public static final String TIPO_REGISTRO_HEADER = "0";
	public static final String TIPO_REGISTRO_LOTE = "1";
	public static final String TIPO_REGISTRO_SEGMENTO_P = "3";
	public static final String TIPO_REGISTRO_SEGMENTO_Q = "3";
	public static final String TIPO_REGISTRO_TRAILER_LOTE = "5";
	public static final String TIPO_REGISTRO_TRAILER_HEADER = "9";

	// Tipo de Inscri��o da SPTRANS
	public static final String TIPO_INSCRICAO_SPTRANS = "2";
	
	// Tipo de Inscri��o do SACADO
	public static final String TIPO_INSCRICAO_SACADO_CPF = "1";
	public static final String TIPO_INSCRICAO_SACADO_CNPJ = "2";
	
	// Vers�o do LAYOUT do Arquivo de Remessa
	public static final String VERSAO_LAYOUT_ARQUIVO_REMESSA = "050";
	
	// Fase da remessa
	public static final String FASE_REMESSA_TESTE = "REMESSA-TESTE";
	public static final String FASE_REMESSA_PRODUCAO = "REMESSA-PRODUCAO";
	
	// C�digo de Remessa
	public static final String CODIGO_REMESSA = "1";
	
	//C�digo Segmento do Registro no Lote P
	public static final String CODIGO_SEGMENTO_REGISTRO_LOTE_P = "P";
	
	//C�digo Segmento do Registro no Lote Q
	public static final String CODIGO_SEGMENTO_REGISTRO_LOTE_Q = "Q";
	
	//C�digo de Movimento Remessa
	public static final String CODIGO_MOVIMENTO_REMESSA = "01";	
	
	//Modalidade da Carteira
	public static final String CODIGO_MODALIDADE_CARTEIRA = "14";
	
	//C�digo da Carteira
	public static final String CODIGO_CARTEIRA = "1";
	
	//Forma de Cadastramento do T�tulo no Banco
	public static final String CODIGO_FORMA_CADASTRAMENTO_TITULO_BANCO = "1";	
	
	//Tipo de Documento
	public static final String CODIGO_TIPO_DOCUMENTO = "2";	
	
	//Identifica��o da Emiss�o do Bloqueto
	public static final String CODIGO_IDENTIFICACAO_EMISSAO_BLOQUETO = "2";	
	
	//Identifica��o da Emiss�o do Bloqueto
	public static final String CODIGO_IDENTIFICACAO_ENTREGA_BLOQUETO = "0";		
	
	//Esp�cie do T�tulo
	public static final String CODIGO_ESPECIE_TITULO = "99";			
	
	//Identifica��o de T�tulo Aceito/N�o Aceito
	public static final String CODIGO_IDENTIFICACAO_TITULO = "N";		
	
	//C�digo do Juros de Mora
	public static final String CODIGO_JUROS_MORA = "3";		
	
	//C�digo do Desconto 1
	public static final String CODIGO_DESCONTO = "0";	
	
	//C�digo para Protesto
	public static final String CODIGO_PROTESTO = "3";
	
	//C�digo para Protesto
	public static final String CODIGO_BAIXA_DEVOLUCAO = "1";

	//C�digo da Moeda
	public static final String CODIGO_MOEDA = "09";
	
	//C�digo Tipo de Opera��o
	public static final String CODIGO_TIPO_OPERACAO = "R";
	
	//C�digo Tipo de Servi�o
	public static final String CODIGO_TIPO_SERVICO = "01";	
	
	//C�digo N�mero da Vers�o do Layout do Lote
	public static final String CODIGO_NUMERO_VERSAO_LAYOUT = "030";		
	
	//C�digo Tipo de Inscri��o da Empresa
	public static final String CODIGO_TIPO_INSCRICAO_EMPRESA = "2";	
	
	
}	
