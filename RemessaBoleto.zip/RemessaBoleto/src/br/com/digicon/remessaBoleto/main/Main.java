package br.com.digicon.remessaBoleto.main;

import org.apache.log4j.Logger;
import br.com.digicon.remessaBoleto.exception.DigiconEncryptorException;
import br.com.digicon.remessaBoleto.service.*;
import br.com.digicon.remessaBoleto.spring.SingletonBeanFactory;


public class Main {
	
	private static final transient Logger LOG = Logger.getLogger(Main.class);
	
	private static String VERSAO = "1.0.3";

	public static void main(String[] args) throws DigiconEncryptorException {
		
		LOG.info("Iniciando o aplicativo SPTrans - Remessa Boleto (" + VERSAO + ")");
		
		Main main = new Main();
		main.init(args[0].toString());
		//main.init("SCA");     
		//main.init("VCW");
		//main.init("LV");
		LOG.info("Finalizado o aplicativo SPTrans - Remessa Boleto (" + VERSAO + ")");
	}

	private void init(String nomeSistema){
		
 		if(nomeSistema.equalsIgnoreCase("LV")){
			LOG.info("Carregando Modulo LV...");
			((RemessaBoletoLVService)SingletonBeanFactory.getBeanFactory().getBean("remessaBoletoLVService")).executar();
		}
		
		if(nomeSistema.equalsIgnoreCase("SCA")){
			LOG.info("Carregando Modulo SA...");
			((RemessaBoletoSAService)SingletonBeanFactory.getBeanFactory().getBean("remessaBoletoSAService")).executar();
		}
		
		if(nomeSistema.equalsIgnoreCase("VCW")){
			LOG.info("Carregando Modulo VCW...");
			((RemessaBoletoVCWService)SingletonBeanFactory.getBeanFactory().getBean("remessaBoletoVCWService")).executar();
		}
	}
	
}