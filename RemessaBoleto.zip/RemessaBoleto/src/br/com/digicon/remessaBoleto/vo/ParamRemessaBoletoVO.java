package br.com.digicon.remessaBoleto.vo;

import java.util.Date;

public class ParamRemessaBoletoVO {
	public String nomeArquivoAGerar;
	public Long codBancoCompensacao;
	public Long cnpjCedente;
	public Long agencia;
	public Integer dvAgencia;
	public Long dvContaCorrente;
	public Long codigoCedente;
	public String nomeBanco;
	public String nomeCedente;
	public String mensagem1;
	public String mensagem2;
	
	public String horaGeracao;
	public String dataGeracao;
	public String dataGeracaoArquivo;
	public String dataVencimento;
	public Long valorNominal;
	public String dataEmissao;
	public Long valorIof;
	public Long valorAbatimento;
	public String numeroDiasBaixa;
	public String cnpjSpTrans;
	public String nomeSacado;
	public String enderecoSacado;	
	public String bairroSacado;	
	public Long cepSacado;
	public Long sufixoCepSacado;
	public String cidadeSacado;
	public String ufSacado;
	public Long qtdeLotesArquivo;
	public Long qtdeRegistrosArquivo;
	public Long numeroInscricaoEmpresa;
	public Long codigoConvenioBanco;
	public String nomeEmpresa;
	public String dataGravacao;
	public Long qtdeRegistrosLote;
	public Long identificacaoTitulo;
	public Long numeroSequencialRegLote;
	public Long qtdeDiasDevolucao;
	public Boolean lockObjeto;
	public Long qtdeMaxDiasVenc;
	public String nomeArquivo;
	//Sys_Domain_Value
	public Long processoId;
	public Long codStatus;
	public Date dataInicioProcesso;
	public Date dataFimProcesso;
	public Long codigoErro;	
	public String mensagemErro;
	
	public Long arquivoId;
	public String pathArquivo;
	public Long numeroRemessa;
	public Long qtdeBoletosArquivo;
	public Long qtdeMaxBoletosArquivo;
	public Date dataAlteracao;
	public Date dataInicioGeracao;
	public String dataConsultaBoleto;
	public String caminhoGravacaoArquivo;
	public String caminhoGravacaoArquivoVcwEst;
	public String caminhoGravacaoArquivoVcwComum;
	
	public String enderecoSacadoPadrao;	
	public String bairroSacadoPadrao;	
	public Long cepSacadoPadrao;
	public Long sufixoCepSacadoPadrao;
	public String cidadeSacadoPadrao;
	public String ufSacadoPadrao;
	
	public String codigoCedenteScaA;
	public String codigoCedenteScaB;
	public String codigoCedenteVcwComum;
	public String codigoCedenteVcwEstudante;
	
	public Long getCodBancoCompensacao() {
		return codBancoCompensacao;
	}
	public void setCodBancoCompensacao(Long codBancoCompensacao) {
		this.codBancoCompensacao = codBancoCompensacao;
	}
	public Long getCnpjCedente() {
		return cnpjCedente;
	}
	public void setCnpjCedente(Long cnpjCedente) {
		this.cnpjCedente = cnpjCedente;
	}
	public Long getAgencia() {
		return agencia;
	}
	public void setAgencia(Long agencia) {
		this.agencia = agencia;
	}
	public Integer getDvAgencia() {
		return dvAgencia;
	}
	public void setDvAgencia(Integer dvAgencia) {
		this.dvAgencia = dvAgencia;
	}
	public Long getCodigoCedente() {
		return codigoCedente;
	}
	public void setCodigoCedente(Long codigoCedente) {
		this.codigoCedente = codigoCedente;
	}
	public String getNomeBanco() {
		return nomeBanco;
	}
	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}
	public String getNomeCedente() {
		return nomeCedente;
	}
	public void setNomeCedente(String nomeCedente) {
		this.nomeCedente = nomeCedente;
	}
	public String getMensagem1() {
		return mensagem1;
	}
	public void setMensagem1(String mensagem1) {
		this.mensagem1 = mensagem1;
	}
	public String getMensagem2() {
		return mensagem2;
	}
	public void setMensagem2(String mensagem2) {
		this.mensagem2 = mensagem2;
	}
	public Long getDvContaCorrente() {
		return dvContaCorrente;
	}
	public void setDvContaCorrente(Long dvContaCorrente) {
		this.dvContaCorrente = dvContaCorrente;
	}
	public String getNomeArquivoAGerar() {
		return nomeArquivoAGerar;
	}
	public void setNomeArquivoAGerar(String nomeArquivoAGerar) {
		this.nomeArquivoAGerar = nomeArquivoAGerar;
	}
	public String getDataVencimento() {
		return dataVencimento;
	}
	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}
	public Long getValorNominal() {
		return valorNominal;
	}
	public void setValorNominal(Long valorNominal) {
		this.valorNominal = valorNominal;
	}
	public String getDataEmissao() {
		return dataEmissao;
	}
	public void setDataEmissao(String dataEmissao) {
		this.dataEmissao = dataEmissao;
	}

	public Long getValorIof() {
		return valorIof;
	}
	public void setValorIof(Long valorIof) {
		this.valorIof = valorIof;
	}
	
	public Long getValorAbatimento() {
		return valorAbatimento;
	}
	
	public void setValorAbatimento(Long valorAbatimento) {
		this.valorAbatimento = valorAbatimento;
	}
	public String getNumeroDiasBaixa() {
		return numeroDiasBaixa;
	}
	public void setNumeroDiasBaixa(String numeroDiasBaixa) {
		this.numeroDiasBaixa = numeroDiasBaixa;
	}
	public String getCnpjSpTrans() {
		return cnpjSpTrans;
	}
	public void setCnpjSpTrans(String cnpjSpTrans) {
		this.cnpjSpTrans = cnpjSpTrans;
	}
	public String getNomeSacado() {
		return nomeSacado;
	}
	public void setNomeSacado(String nomeSacado) {
		this.nomeSacado = nomeSacado;
	}
	public String getEnderecoSacado() {
		return enderecoSacado;
	}
	public void setEnderecoSacado(String enderecoSacado) {
		this.enderecoSacado = enderecoSacado;
	}
	public String getBairroSacado() {
		return bairroSacado;
	}
	public void setBairroSacado(String bairroSacado) {
		this.bairroSacado = bairroSacado;
	}
	public Long getCepSacado() {
		return cepSacado;
	}
	public void setCepSacado(Long cepSacado) {
		this.cepSacado = cepSacado;
	}
	public Long getSufixoCepSacado() {
		return sufixoCepSacado;
	}
	public void setSufixoCepSacado(Long sufixoCepSacado) {
		this.sufixoCepSacado = sufixoCepSacado;
	}
	public String getCidadeSacado() {
		return cidadeSacado;
	}
	public void setCidadeSacado(String cidadeSacado) {
		this.cidadeSacado = cidadeSacado;
	}
	
	public String getUfSacado() {
		return ufSacado;
	}
	public void setUfSacado(String ufSacado) {
		this.ufSacado = ufSacado;
	}
	
	public Long getQtdeLotesArquivo() {
		return qtdeLotesArquivo;
	}
	public void setQtdeLotesArquivo(Long qtdeLotesArquivo) {
		this.qtdeLotesArquivo = qtdeLotesArquivo;
	}
	public Long getQtdeRegistrosArquivo() {
		return qtdeRegistrosArquivo;
	}
	public void setQtdeRegistrosArquivo(Long qtdeRegistrosArquivo) {
		this.qtdeRegistrosArquivo = qtdeRegistrosArquivo;
	}
	public Long getNumeroInscricaoEmpresa() {
		return numeroInscricaoEmpresa;
	}
	public void setNumeroInscricaoEmpresa(Long numeroInscricaoEmpresa) {
		this.numeroInscricaoEmpresa = numeroInscricaoEmpresa;
	}
	public Long getCodigoConvenioBanco() {
		return codigoConvenioBanco;
	}
	public void setCodigoConvenioBanco(Long codigoConvenioBanco) {
		this.codigoConvenioBanco = codigoConvenioBanco;
	}
	public String getNomeEmpresa() {
		return nomeEmpresa;
	}
	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}
	public String getDataGravacao() {
		return dataGravacao;
	}
	public void setDataGravacao(String dataGravacao) {
		this.dataGravacao = dataGravacao;
	}
	public Long getQtdeRegistrosLote() {
		return qtdeRegistrosLote;
	}
	public void setQtdeRegistrosLote(Long qtdeRegistrosLote) {
		this.qtdeRegistrosLote = qtdeRegistrosLote;
	}
	public String getDataGeracao() {
		return dataGeracao;
	}
	public void setDataGeracao(String dataGeracao) {
		this.dataGeracao = dataGeracao;
	}
	public String getHoraGeracao() {
		return horaGeracao;
	}
	public void setHoraGeracao(String horaGeracao) {
		this.horaGeracao = horaGeracao;
	}
	
	public Long getIdentificacaoTitulo() {
		return identificacaoTitulo;
	}

	public void setIdentificacaoTitulo(Long identificacaoTitulo) {
		this.identificacaoTitulo = identificacaoTitulo;
	}
	
	public Long getNumeroSequencialRegLote() {
		return numeroSequencialRegLote;
	}
	
	public void setNumeroSequencialRegLote(Long numeroSequencialRegLote) {
		this.numeroSequencialRegLote = numeroSequencialRegLote;
	}
	
	public Long getQtdeDiasDevolucao() {
		return qtdeDiasDevolucao;
	}
	
	public void setQtdeDiasDevolucao(Long qtdeDiasDevolucao) {
		this.qtdeDiasDevolucao = qtdeDiasDevolucao;
	}
	
	public String getDataGeracaoArquivo() {
		return dataGeracaoArquivo;
	}
	
	public void setDataGeracaoArquivo(String dataGeracaoArquivo) {
		this.dataGeracaoArquivo = dataGeracaoArquivo;
	}
	
	public Boolean getLockObjeto() {
		return lockObjeto;
	}
	
	public void setLockObjeto(Boolean lockObjeto) {
		this.lockObjeto = lockObjeto;
	}
	
	public Long getQtdeMaxDiasVenc() {
		return qtdeMaxDiasVenc;
	}
	
	public void setQtdeMaxDiasVenc(Long qtdeMaxDiasVenc) {
		this.qtdeMaxDiasVenc = qtdeMaxDiasVenc;
	}
	
	public Long getProcessoId() {
		return processoId;
	}
	
	public void setProcessoId(Long processoId) {
		this.processoId = processoId;
	}
	
	public Date getDataInicioProcesso() {
		return dataInicioProcesso;
	}
	public void setDataInicioProcesso(Date dataInicioProcesso) {
		this.dataInicioProcesso = dataInicioProcesso;
	}
	
	public Date getDataFimProcesso() {
		return dataFimProcesso;
	}

	public void setDataFimProcesso(Date dataFimProcesso) {
		this.dataFimProcesso = dataFimProcesso;
	}
	public Long getCodigoErro() {
		return codigoErro;
	}
	
	public void setCodigoErro(Long codigoErro) {
		this.codigoErro = codigoErro;
	}
	public String getMensagemErro() {
		return mensagemErro;
	}
	public void setMensagemErro(String mensagemErro) {
		this.mensagemErro = mensagemErro;
	}
	
	public Long getCodStatus() {
		return codStatus;
	}
	
	public void setCodStatus(Long codStatus) {
		this.codStatus = codStatus;
	}

	public String getNomeArquivo() {
		return nomeArquivo;
	}

	public void setNomeArquivo(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
	}
	
	public Long getArquivoId() {
		return arquivoId;
	}
	
	public void setArquivoId(Long arquivoId) {
		this.arquivoId = arquivoId;
	}

	public String getPathArquivo() {
		return pathArquivo;
	}

	public void setPathArquivo(String pathArquivo) {
		this.pathArquivo = pathArquivo;
	}

	public Long getNumeroRemessa() {
		return numeroRemessa;
	}

	public void setNumeroRemessa(Long numeroRemessa) {
		this.numeroRemessa = numeroRemessa;
	}
	
	public Long getQtdeBoletosArquivo() {
		return qtdeBoletosArquivo;
	}

	public void setQtdeBoletosArquivo(Long qtdeBoletosArquivo) {
		this.qtdeBoletosArquivo = qtdeBoletosArquivo;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public String getDataConsultaBoleto() {
		return dataConsultaBoleto;
	}

	
	public void setDataConsultaBoleto(String dataConsultaBoleto) {
		this.dataConsultaBoleto = dataConsultaBoleto;
	}
	
	public Date getDataInicioGeracao() {
		return dataInicioGeracao;
	}
	
	public void setDataInicioGeracao(Date dataInicioGeracao) {
		this.dataInicioGeracao = dataInicioGeracao;
	}
	
	
	public String getCaminhoGravacaoArquivo() {
		return caminhoGravacaoArquivo;
	}
	
	
	public void setCaminhoGravacaoArquivo(String caminhoGravacaoArquivo) {
		this.caminhoGravacaoArquivo = caminhoGravacaoArquivo;
	}
	
	public String getEnderecoSacadoPadrao() {
		return enderecoSacadoPadrao;
	}
	
	public void setEnderecoSacadoPadrao(String enderecoSacadoPadrao) {
		this.enderecoSacadoPadrao = enderecoSacadoPadrao;
	}
	
	public String getBairroSacadoPadrao() {
		return bairroSacadoPadrao;
	}
	public void setBairroSacadoPadrao(String bairroSacadoPadrao) {
		this.bairroSacadoPadrao = bairroSacadoPadrao;
	}
	
	public Long getCepSacadoPadrao() {
		return cepSacadoPadrao;
	}
	
	public void setCepSacadoPadrao(Long cepSacadoPadrao) {
		this.cepSacadoPadrao = cepSacadoPadrao;
	}
	
	public Long getSufixoCepSacadoPadrao() {
		return sufixoCepSacadoPadrao;
	}
	
	public void setSufixoCepSacadoPadrao(Long sufixoCepSacadoPadrao) {
		this.sufixoCepSacadoPadrao = sufixoCepSacadoPadrao;
	}
	
	public String getCidadeSacadoPadrao() {
		return cidadeSacadoPadrao;
	}
	
	public void setCidadeSacadoPadrao(String cidadeSacadoPadrao) {
		this.cidadeSacadoPadrao = cidadeSacadoPadrao;
	}
	
	public String getUfSacadoPadrao() {
		return ufSacadoPadrao;
	}
	
	public void setUfSacadoPadrao(String ufSacadoPadrao) {
		this.ufSacadoPadrao = ufSacadoPadrao;
	}
	
	public String getCodigoCedenteScaA() {
		return codigoCedenteScaA;
	}
	
	public void setCodigoCedenteScaA(String codigoCedenteScaA) {
		this.codigoCedenteScaA = codigoCedenteScaA;
	}
	
	public String getCodigoCedenteScaB() {
		return codigoCedenteScaB;
	}
	
	public void setCodigoCedenteScaB(String codigoCedenteScaB) {
		this.codigoCedenteScaB = codigoCedenteScaB;
	}
	
	public String getCodigoCedenteVcwComum() {
		return codigoCedenteVcwComum;
	}
	
	public void setCodigoCedenteVcwComum(String codigoCedenteVcwComum) {
		this.codigoCedenteVcwComum = codigoCedenteVcwComum;
	}
	
	public String getCodigoCedenteVcwEstudante() {
		return codigoCedenteVcwEstudante;
	}
	
	public void setCodigoCedenteVcwEstudante(String codigoCedenteVcwEstudante) {
		this.codigoCedenteVcwEstudante = codigoCedenteVcwEstudante;
	}
	
	public String getCaminhoGravacaoArquivoVcwEst() {
		return caminhoGravacaoArquivoVcwEst;
	}
	
	public void setCaminhoGravacaoArquivoVcwEst(String caminhoGravacaoArquivoVcwEst) {
		this.caminhoGravacaoArquivoVcwEst = caminhoGravacaoArquivoVcwEst;
	}
	
	public String getCaminhoGravacaoArquivoVcwComum() {
		return caminhoGravacaoArquivoVcwComum;
	}
	
	public void setCaminhoGravacaoArquivoVcwComum(String caminhoGravacaoArquivoVcwComum) {
		this.caminhoGravacaoArquivoVcwComum = caminhoGravacaoArquivoVcwComum;
	}
	
	public Long getQtdeMaxBoletosArquivo() {
		return qtdeMaxBoletosArquivo;
	}
	
	public void setQtdeMaxBoletosArquivo(Long qtdeMaxBoletosArquivo) {
		this.qtdeMaxBoletosArquivo = qtdeMaxBoletosArquivo;
	}
	
}
