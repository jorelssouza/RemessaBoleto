package br.com.digicon.remessaBoleto.vo;

public class ValoresDominioVO {
	private String domainName;
	private Long codeNumber;
	private String itemName;
	private String description;


	// Constructors
	public ValoresDominioVO(){}

	public ValoresDominioVO(String domainName) {
		this.domainName = domainName;
	}

	public ValoresDominioVO(String domainName, String itemName) {
		this.domainName = domainName;
		this.itemName = itemName;
	}

	public ValoresDominioVO(String domainName, Long codeNumber){
		this.domainName = domainName;
		this.codeNumber = codeNumber;
	}

	public ValoresDominioVO(String domainName, String description, Long codeNumber){
		this.domainName = domainName;
		this.description = description;
		this.codeNumber = codeNumber;
	}

	// Getters/Setters
	public Long getCodeNumber() {
		return codeNumber;
	}
	public void setCodeNumber(Long codeNumber) {
		this.codeNumber = codeNumber;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
}
