package br.com.digicon.remessaBoleto.vo;

import java.util.List;
import br.com.digicon.remessaBoleto.vo.SysParameterVO;


public class SysParameterDTO extends SysParameterVO {
	private List listaDominio;

	public List getListaDominio() {
		return listaDominio;
	}

	public void setListaDominio(List listaDominio) {
		this.listaDominio = listaDominio;
	}
	
}
