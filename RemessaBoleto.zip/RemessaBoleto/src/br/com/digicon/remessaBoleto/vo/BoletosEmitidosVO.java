package br.com.digicon.remessaBoleto.vo;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.jboleto.JBoletoBean;

public class BoletosEmitidosVO {
    private Long idBoletosEmitidos;
    private Long idBoleto;
    private Date dataEmissao;
    private Date dataPagamento;
    private Date vencimento;
    private Double valor;
    private Long nossoNumero;
    private Integer status;
    private Integer tipoRecebimento;
    private Integer statusBaixa;
    private String observacao;
    private Integer tipoBoleto;
    private String boleto;
    private Long requestId;
    private String processado;
    private Double valorTaxa;
    private String obsBaixa;
    private String tipoPessoa;
    private Long arquivoRemessaId;
    private String flgProcRemessaBoleto;
    private String flgStatusRegistro;
    private Date dtRegistroBancoCedente;
    private JBoletoBean  jBoleto; 
    
 
    

  //  private RequisicaoVO requisicao;

    // Fields Auxiliares

    @SuppressWarnings("unused")
    private Date dataEmissaoFormat;
    @SuppressWarnings("unused")
    private Date dataPagamentoFormat;
    @SuppressWarnings("unused")
    private Date vencimentoFormat;
    @SuppressWarnings("unused")
    private Double valorFormat;
    @SuppressWarnings("unused")
    private Double valorTaxaFormat;
    @SuppressWarnings("unused")
    private String nossoNumeroStr;

    private DateFormat mDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    private DecimalFormat moneyFormat = new DecimalFormat("#,###,###.00");

    // Constructors
    public BoletosEmitidosVO() {
    }

    public BoletosEmitidosVO(Long idBoletosEmitidos) {
        this.idBoletosEmitidos = idBoletosEmitidos;
    }

    public BoletosEmitidosVO(Date vencimento, Long nossoNumero) {
        this.vencimento = vencimento;
        this.nossoNumero = nossoNumero;
    }

    // M�todos Auxiliares
    public String getNossoNumeroStr() {
        return this.getNossoNumero().toString();
    }

    public void setNossoNumeroStr(String nossoNumeroStr){
    	this.nossoNumeroStr = nossoNumeroStr;
    }

    public String getVencimentoFormat() {
        String retorno = "";
        try {
            retorno = mDateFormat.format(this.vencimento);
        } catch (Exception e) {
            retorno = "";
        }
        return retorno;
    }

    public String getDataEmissaoFormat() {
        String retorno = "";
        try {
            retorno = mDateFormat.format(this.dataEmissao);
        } catch (Exception e) {
            retorno = "";
        }
        return retorno;
    }

    public String getDataPagamentoFormat() {
        String retorno = "";
        try {
            retorno = mDateFormat.format(this.dataPagamento);
        } catch (Exception e) {
            retorno = "";
        }
        return retorno;
    }

    public String getValorFormat() {
        String retorno = "";
        try {
            retorno = this.moneyFormat.format(this.valor);
        } catch (Exception e) {
            retorno = "";
        }
        return retorno;
    }

    public String getValorTaxaFormat() {
        String retorno = "";
        try {
            retorno = this.moneyFormat.format(this.valorTaxa);
        } catch (Exception e) {
            retorno = "";
        }
        return retorno;
    }

    public void setDataEmissaoFormat(Date dataEmissaoFormat) {
        this.dataEmissaoFormat = dataEmissaoFormat;
    }

    public void setDataPagamentoFormat(Date dataPagamentoFormat) {
        this.dataPagamentoFormat = dataPagamentoFormat;
    }

    public void setVencimentoFormat(Date vencimentoFormat) {
        this.vencimentoFormat = vencimentoFormat;
    }

    // Getters/Setters
    public Date getDataEmissao() {
        return dataEmissao;
    }

    public void setDataEmissao(Date dataEmissao) {
        this.dataEmissao = dataEmissao;
    }

    public Date getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(Date dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public Long getIdBoleto() {
        return idBoleto;
    }

    public void setIdBoleto(Long idBoleto) {
        this.idBoleto = idBoleto;
    }

    public Long getIdBoletosEmitidos() {
        return idBoletosEmitidos;
    }

    public void setIdBoletosEmitidos(Long idBoletosEmitidos) {
        this.idBoletosEmitidos = idBoletosEmitidos;
    }

    public Long getNossoNumero() {
        return nossoNumero;
    }

    public void setNossoNumero(Long nossoNumero) {
        this.nossoNumero = nossoNumero;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getTipoRecebimento() {
        return tipoRecebimento;
    }

    public void setTipoRecebimento(Integer tipoRecebimento) {
        this.tipoRecebimento = tipoRecebimento;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Date getVencimento() {
        return vencimento;
    }

    public void setVencimento(Date vencimento) {
        this.vencimento = vencimento;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public Integer getStatusBaixa() {
        return statusBaixa;
    }

    public void setStatusBaixa(Integer statusBaixa) {
        this.statusBaixa = statusBaixa;
    }

    public String getBoleto() {
        return boleto;
    }

    public void setBoleto(String boleto) {
        this.boleto = boleto;
    }

    public Integer getTipoBoleto() {
        return tipoBoleto;
    }

    public void setTipoBoleto(Integer tipoBoleto) {
        this.tipoBoleto = tipoBoleto;
    }

    public Long getRequestId() {
        return requestId;
    }

    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

    public String getProcessado() {
        return this.processado;
    }

    public void setProcessado(String processado) {
        this.processado = processado;
    }

	public Double getValorTaxa() {
		return valorTaxa;
	}

	public void setValorTaxa(Double valorTaxa) {
		this.valorTaxa = valorTaxa;
	}

	public String getObsBaixa() {
		return obsBaixa;
	}

	public void setObsBaixa(String obsBaixa) {
		this.obsBaixa = obsBaixa;
	}

	
	public JBoletoBean getjBoleto() {
		return jBoleto;
	}


	public void setjBoleto(JBoletoBean jBoleto) {
		this.jBoleto = jBoleto;
	}

	public Long getArquivoRemessaId() {
		return arquivoRemessaId;
	}

	public void setArquivoRemessaId(Long arquivoRemessaId) {
		this.arquivoRemessaId = arquivoRemessaId;
	}

	public String getFlgProcRemessaBoleto() {
		return flgProcRemessaBoleto;
	}

	public void setFlgProcRemessaBoleto(String flgProcRemessaBoleto) {
		this.flgProcRemessaBoleto = flgProcRemessaBoleto;
	}

	public String getFlgStatusRegistro() {
		return flgStatusRegistro;
	}

	public void setFlgStatusRegistro(String flgStatusRegistro) {
		this.flgStatusRegistro = flgStatusRegistro;
	}

	public Date getDtRegistroBancoCedente() {
		return dtRegistroBancoCedente;
	}

	public void setDtRegistroBancoCedente(Date dtRegistroBancoCedente) {
		this.dtRegistroBancoCedente = dtRegistroBancoCedente;
	}

	public String getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	

}
