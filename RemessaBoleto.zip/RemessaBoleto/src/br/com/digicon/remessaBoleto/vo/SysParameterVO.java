package br.com.digicon.remessaBoleto.vo;

public class SysParameterVO {
	public static final String PERMITE_COMPRA_ESTUDANTE_QUALQUER_CARTAO = "PERMITE_COMPRA_QUALQUER_CARTAO";
	public static final String VALOR_SIM = "S";
	
    private String parameterName;
    private String parameterValue;
    private String description;
    private Long fieldTypeId;
    private String domainName;
    private Long visible;

    public SysParameterVO(){}

	public SysParameterVO(Long visible) {
		this.visible = visible;
	}

	public SysParameterVO(String parameterName, String parameterValue) {
		this.parameterName = parameterName;
		this.parameterValue = parameterValue;
	}

	public SysParameterVO(String parameterName) {
		this.parameterName = parameterName;
	}

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public Long getFieldTypeId() {
		return fieldTypeId;
	}
	public void setFieldTypeId(Long fieldTypeId) {
		this.fieldTypeId = fieldTypeId;
	}
	public String getParameterName() {
		return parameterName;
	}
	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}
	public String getParameterValue() {
		return parameterValue;
	}
	public void setParameterValue(String parameterValue) {
		this.parameterValue = parameterValue;
	}
	public Long getVisible() {
		return visible;
	}
	public void setVisible(Long visible) {
		this.visible = visible;
	}
}
