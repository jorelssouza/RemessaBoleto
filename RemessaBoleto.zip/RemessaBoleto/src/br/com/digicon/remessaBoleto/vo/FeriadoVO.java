package br.com.digicon.remessaBoleto.vo;

import java.util.Date;

public class FeriadoVO {

	private Date data;
	private String descricaoFeriado;

	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public String getDescricaoFeriado() {
		return descricaoFeriado;
	}
	public void setDescricaoFeriado(String descricaoFeriado) {
		this.descricaoFeriado = descricaoFeriado;
	}


}
