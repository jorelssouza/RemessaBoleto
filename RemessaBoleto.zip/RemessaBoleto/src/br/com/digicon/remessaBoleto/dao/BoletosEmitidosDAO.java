package br.com.digicon.remessaBoleto.dao;

import java.util.Date;
import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import br.com.digicon.remessaBoleto.vo.BoletosEmitidosVO;

@SuppressWarnings("unchecked")
public class BoletosEmitidosDAO extends SqlMapClientDaoSupport {

    /**
     * Retorna uma lista de objetos BoletosEmitidosVO  do SA
     *
     * @return List (BoletosEmitidosVO)
     */
    @SuppressWarnings("unchecked")
    public List<BoletosEmitidosVO> listaBoletosSA(Date data) {
    	List<BoletosEmitidosVO> lista =	getSqlMapClientTemplate().queryForList("BoletosEmitidos.selectBoletosSA",data); 
        return lista; 
    }
    
    @SuppressWarnings("unchecked")
    public Long obterNumeroNSA(){
         Long numeroNSA = (Long) getSqlMapClientTemplate().queryForObject("BoletosEmitidos.selectNSA");    
         return numeroNSA;
    }
    
    @SuppressWarnings("unchecked")
    public Long obterNumeroNSAVCW(){
         Long numeroNSA = (Long) getSqlMapClientTemplate().queryForObject("BoletosEmitidos.selectNSAVCW"); 
         return numeroNSA;
    }
    
    
    @SuppressWarnings("unchecked")
    public Long obterProcessoId(){
         Long processoID = (Long) getSqlMapClientTemplate().queryForObject("BoletosEmitidos.selectProcessoID"); 
         return processoID;
    }
    
   
    
    @SuppressWarnings("unchecked")
    public Long obterProcessoDetalheIdSA(){
         Long processoDetalheID = (Long) getSqlMapClientTemplate().queryForObject("BoletosEmitidos.selectProcessoDetalheIDSA"); 
         return processoDetalheID;
    }

    
    
    @SuppressWarnings("unchecked")
    public Long obterProcessoDetalheIdVCW(){
         Long processoDetalheID = (Long) getSqlMapClientTemplate().queryForObject("BoletosEmitidos.selectProcessoDetalheIDVCW"); 
         return processoDetalheID;
    }

   
    
    
    /**
     * Atualiza tabela sptrans.tb_boletos_emitidos Status para '1' (Baixado)
     * @param ID_BOLETOS_EMITIDOS (String)
     */
    public void atualizaFlagBoletoRemessaSA(BoletosEmitidosVO boleto) {
        getSqlMapClientTemplate().update("BoletosEmitidos.updateFlagBoletoRemessaSA", boleto);
    }
    
    
    /**
     * Atualiza tabela spservice.tb_cob_boleto status_boleto para '1' (Baixado)
     * @param ID_BOLETOS_EMITIDOS (String)
     */
    public void updateFlagBoletoRemessaVCW(BoletosEmitidosVO boleto) {
        getSqlMapClientTemplate().update("BoletosEmitidos.updateFlagBoletoRemessaVCW", boleto);
    }
    
    
    
    /**
     * Retorna uma lista de objetos BoletosEmitidosVO do VCW
     *
     * @return List (BoletosEmitidosVO)
     */
    @SuppressWarnings("unchecked")
    public List<BoletosEmitidosVO> listaBoletosVCW(Date data) {
    	List<BoletosEmitidosVO> lista =	getSqlMapClientTemplate().queryForList("BoletosEmitidos.selectBoletosVCW",data); 
        return lista; 
    }

}
