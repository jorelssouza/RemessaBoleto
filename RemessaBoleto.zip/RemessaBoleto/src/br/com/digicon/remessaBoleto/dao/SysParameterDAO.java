package br.com.digicon.remessaBoleto.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import br.com.digicon.remessaBoleto.vo.ParamRemessaBoletoVO;
import br.com.digicon.remessaBoleto.vo.SysParameterVO;
import br.com.digicon.remessaBoleto.vo.ValoresDominioVO;
import br.com.digicon.remessaBoleto.vo.FeriadoVO;

/*
 * Acesso SA
 * 
 * */
public class SysParameterDAO extends SqlMapClientDaoSupport {

    
    @SuppressWarnings("unchecked")
    public List<SysParameterVO> findAllParametersByPrefixLista() { 
    	List<SysParameterVO> lista = (List<SysParameterVO>) getSqlMapClientTemplate().queryForList("SysParameter.selectByPrefixLista"); 
        return lista; 
    }

    public SysParameterVO findByParameterName(SysParameterVO vo) {
        return (SysParameterVO) getSqlMapClientTemplate().queryForObject("SysParameter.selectByParameterName", vo);
    }

    @SuppressWarnings("unchecked")
    public List findByVisible(SysParameterVO vo) {
        return getSqlMapClientTemplate().queryForList("SysParameter.selectByVisible", vo);
    }

    @SuppressWarnings("unchecked")
    public List findDTOByVisible(SysParameterVO vo) {
        return getSqlMapClientTemplate().queryForList("SysParameter.selectDTOByVisible", vo);
    }

    public int updateValueByParameterName(SysParameterVO vo) {
        return getSqlMapClientTemplate().update("SysParameter.updateValueByParameterName", vo);
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> findAllParametersByPrefix(SysParameterVO parameterVO) {
        return getSqlMapClientTemplate().queryForMap("SysParameter.selectByPrefix", parameterVO, "parameterName",
                "parameterValue");
    }
    

    public int inserirParameterMap(SysParameterVO parameterVO) {
        getSqlMapClientTemplate().insert("SysParameter.insertParameter", parameterVO);
        return 0;
    }
    
    /**
     * Trava ou destrava a Execu��o da Gera��o do Arquivo de Remessa
     * @param boleto (String)
     * 
     */
    public void travarObjetoRemessaSA(String lock) {
        getSqlMapClientTemplate().update("SysParameter.updateLockRemessaSA", lock);
    }
    
    
    /**
     * Trava ou destrava a Execu��o da Gera��o do Arquivo de Remessa
     * @param boleto (String)
     * 
     */
    public void updateObjetoRemessaVCW(String lock) {
        getSqlMapClientTemplate().update("SysParameter.updateLockRemessaVCW", lock);
    }
    
    
    /**
	 * Retorna objeto ValoresDominioVO
	 * @param vo
	 * @return
	 */
	public ValoresDominioVO findByDominioItemRemessa(ValoresDominioVO vo) {
		return (ValoresDominioVO)getSqlMapClientTemplate().queryForObject("SysParameter.selectByDominioItemRemessa", vo);
	}
    

	public void inserirContrRemessaVCW(ParamRemessaBoletoVO param) {
	       getSqlMapClientTemplate().insert("SysParameter.insertTabControleRemessaVCW", param);
	}
	
	

	public void updateContrRemessaVCW(ParamRemessaBoletoVO param) {
	       getSqlMapClientTemplate().insert("SysParameter.updateTabControleRemessaVCW", param);
	}
	
	public void inserirContrRemessaDetalhesVCW(ParamRemessaBoletoVO param) {
	       getSqlMapClientTemplate().insert("SysParameter.insertTabControleRemessaDetalhesVCW", param);
	}
	
	public void updateTabControleRemessaDetalhesVCW(ParamRemessaBoletoVO param){
		getSqlMapClientTemplate().update("SysParameter.updateTabControleRemessaDetalhesVCW", param);
		
	}
	
	
	public void inserirContrRemessaSA(ParamRemessaBoletoVO param) {
	       getSqlMapClientTemplate().insert("SysParameter.insertTabControleRemessaSA", param);
	}
	
	
	public void updateContrRemessaSA(ParamRemessaBoletoVO param) {
		getSqlMapClientTemplate().update("SysParameter.updateTabControleRemessaSA", param);
	}
	
	
	public void inserirContrRemessaDetalhesSA(ParamRemessaBoletoVO param) {
	     getSqlMapClientTemplate().insert("SysParameter.insertTabControleRemessaDetalhesSA", param);
	}
	
	public void updateContrRemessaDetalhesSA(ParamRemessaBoletoVO param) {
		getSqlMapClientTemplate().update("SysParameter.updateTabControleRemessaDetalhesSA", param);
	}
	
    /**
	 * Consulta tabela de feriados SA e VCW
	 * @param vo
	 * @return List
	 */
	@SuppressWarnings("unchecked")
	public List<FeriadoVO> getFeriados( Date data ){
		return ( List<FeriadoVO> ) this.getSqlMapClientTemplate().queryForList( "SysParameter.getFeriado", data );
	}
	
	
	  /**
	 * Consulta lista de feriados SA e VCW
	 * @param vo
	 * @return List
	 */
	@SuppressWarnings("unchecked")
	public List<Date> getListaFeriados(){
		return ( List<Date> ) this.getSqlMapClientTemplate().queryForList( "SysParameter.getlistaFeriados");
	}
	
	
    
}
