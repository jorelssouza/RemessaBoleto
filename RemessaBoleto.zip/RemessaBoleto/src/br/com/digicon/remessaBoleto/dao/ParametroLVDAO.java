package br.com.digicon.remessaBoleto.dao;

import java.util.Date;
import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import br.com.digicon.remessaBoleto.vo.BoletosEmitidosVO;
import br.com.digicon.remessaBoleto.vo.FeriadoVO;
import br.com.digicon.remessaBoleto.vo.ParamRemessaBoletoVO;
import br.com.digicon.remessaBoleto.vo.SysParameterVO;


/*
 * Acesso LV
 * 
 * */
public class ParametroLVDAO extends SqlMapClientDaoSupport {


    @SuppressWarnings("unchecked")
    public List <SysParameterVO> findAll() {
         List<SysParameterVO> lista = (List<SysParameterVO>) getSqlMapClientTemplate().queryForList("ParametroLV.selectAll");
         return lista;
    }
    
    
    @SuppressWarnings("unchecked")
    public List <BoletosEmitidosVO> searchBoletos(Date dataGeracao) {
         List<BoletosEmitidosVO> lista = (List<BoletosEmitidosVO>) getSqlMapClientTemplate().queryForList("ParametroLV.selectBoletos",dataGeracao);
         return lista;
    }

    @SuppressWarnings("unchecked")
    public Long obterNumeroNSA(){
         Long numeroNSA = (Long) getSqlMapClientTemplate().queryForObject("ParametroLV.selectNSA"); 
         return numeroNSA;
    }
    
    /**
     * Trava ou destrava a Execu��o da Gera��o do Arquivo de Remessa
     * @param boleto (String)
     * 
     */
    public void processarTravaObjetoRemessaLV(String lock) {
        getSqlMapClientTemplate().update("ParametroLV.updateLockRemessa", lock);
    }

    
    /**
     * Atualiza tabela sptranslv.boleto flg_pago para 'E' (Enviado)
     * @param txtNumDoc (String)
     */
    public void updateFlagBoletoRemessaLV(BoletosEmitidosVO boleto) {
        getSqlMapClientTemplate().update("ParametroLV.updateFlagBoletoRemessaLV", boleto);
    }
    
    
    @SuppressWarnings("unchecked")
    public Long obterProcessoIdLV(){
         Long processoID = (Long) getSqlMapClientTemplate().queryForObject("ParametroLV.selectProcessoIDLV"); 
         return processoID;
    }
    
    
    @SuppressWarnings("unchecked")
    public Long getProcessoDetalheIdLV(){
         Long processoDetalheID = (Long) getSqlMapClientTemplate().queryForObject("ParametroLV.selectProcessoDetalheIDLV"); 
         return processoDetalheID;
    }
    
    
	public void insertContrRemessaLV(ParamRemessaBoletoVO param) {
	       getSqlMapClientTemplate().insert("ParametroLV.insertTabControleRemessaLV", param);
	}
	
	
	public void updateContrRemessaLV(ParamRemessaBoletoVO param) {
	       getSqlMapClientTemplate().update("ParametroLV.updateTabControleRemessaLV", param);
	}
	
	public void insertContrRemessaDetalhesLV(ParamRemessaBoletoVO param) {
	       getSqlMapClientTemplate().insert("ParametroLV.insertTabControleRemessaDetalhesLV", param);
	}

	public void updateContrRemessaDetalhesLV(ParamRemessaBoletoVO param) {
	       getSqlMapClientTemplate().update("ParametroLV.updateTabControleRemessaDetalhesLV", param);
	}
	
	 /**
	 * Consulta tabela de feriados LV
	 * @param vo
	 * @return List
	 */
	@SuppressWarnings("unchecked")
	public List<FeriadoVO> getFeriadosLV( Date data ){
		return ( List<FeriadoVO> ) this.getSqlMapClientTemplate().queryForList( "ParametroLV.getFeriadoLV", data );
	}	
    
	
	 /**
	 * Consulta tabela de feriados LV
	 * @param vo
	 * @return List
	 */
	@SuppressWarnings("unchecked")
	public List<Date> getListaFeriadosLV(){
		return ( List<Date> ) this.getSqlMapClientTemplate().queryForList( "ParametroLV.getListaFeriadoLV");
	}	
    
}
