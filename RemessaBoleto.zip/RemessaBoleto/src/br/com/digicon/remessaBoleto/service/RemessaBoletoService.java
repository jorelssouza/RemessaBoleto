package br.com.digicon.remessaBoleto.service;

public interface RemessaBoletoService {
	
	public void executar();
	
}
