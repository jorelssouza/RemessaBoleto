package br.com.digicon.remessaBoleto.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import br.com.digicon.remessaBoleto.facade.RemessaBoletoSAFacade;
import br.com.digicon.remessaBoleto.facade.RemessaBoletoVCWFacade;

public class RemessaBoletoVCWService  implements RemessaBoletoService{
	
	
	private static final transient Logger LOG = Logger.getLogger(RemessaBoletoVCWService.class);
	
	@Autowired
	private RemessaBoletoVCWFacade remessaBoletoVCWFacade;


	public void executar(){
		try{
			
			this.remessaBoletoVCWFacade.updateTravaObjetoRemessa("TRUE");
			this.remessaBoletoVCWFacade.gerarRemessa();
		} catch (Exception e){
			LOG.error(e.getMessage());
		}	
	}


	public RemessaBoletoVCWFacade getRemessaBoletoVCWFacade() {
		return remessaBoletoVCWFacade;
	}

	public void setRemessaBoletoVCWFacade(RemessaBoletoVCWFacade remessaBoletoVCWFacade) {
		this.remessaBoletoVCWFacade = remessaBoletoVCWFacade;
	}

	
	
}
