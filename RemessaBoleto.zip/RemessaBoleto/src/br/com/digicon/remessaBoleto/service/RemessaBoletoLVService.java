package br.com.digicon.remessaBoleto.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import br.com.digicon.remessaBoleto.facade.RemessaBoletoLVFacade;

public class RemessaBoletoLVService  implements RemessaBoletoService{
	
	
	private static final transient Logger LOG = Logger.getLogger(RemessaBoletoLVService.class);
	
	@Autowired
	private RemessaBoletoLVFacade remessaBoletoLVFacade;


	public void executar(){

		try{
			
			this.remessaBoletoLVFacade.processarRemessa();
		} catch (Exception e){
			LOG.error(e.getMessage());
		}	
	}
	
	
	/**
	 * @return the remessaBoletoFacade
	 */
	public RemessaBoletoLVFacade getRemessaBoletoLVFacade() {
		return remessaBoletoLVFacade;
	}

	/**
	 * @param remessaBoletoFacade the remessaBoletoFacade to set
	 */
	public void setRemessaBoletoLVFacade(RemessaBoletoLVFacade remessaBoletoFacade) {
		this.remessaBoletoLVFacade = remessaBoletoFacade;
	}
	
}
