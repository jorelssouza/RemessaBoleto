package br.com.digicon.remessaBoleto.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import br.com.digicon.remessaBoleto.facade.RemessaBoletoSAFacade;

public class RemessaBoletoSAService  implements RemessaBoletoService{
	
	
	private static final transient Logger LOG = Logger.getLogger(RemessaBoletoSAService.class);
	
	@Autowired
	private RemessaBoletoSAFacade remessaBoletoSAFacade;


	public void executar() {
		
		try{
			
			this.remessaBoletoSAFacade.gerarRemessa();
		} catch (Exception e){
			LOG.error(e.getMessage());
		}	
			
	}


	/**
	 * @return the remessaBoletoSAFacade
	 */
	public RemessaBoletoSAFacade getRemessaBoletoSAFacade() {
		return remessaBoletoSAFacade;
	}


	/**
	 * @param remessaBoletoSAFacade the remessaBoletoSAFacade to set
	 */
	public void setRemessaBoletoSAFacade(RemessaBoletoSAFacade remessaBoletoSAFacade) {
		this.remessaBoletoSAFacade = remessaBoletoSAFacade;
	}
	
	
	
}
